import Identifiers.WEIGHTS;
import org.junit.jupiter.api.Test;
import graphComponents.*;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GraphSetupTest {
    Node N1,N2,N3,N4,N5;
    Edge e1,e2,e3;
    Graph g1, g2;
    Node []nodeSet;

    public GraphSetupTest() throws IOException {
        g1 = new Graph();
        g2 = new Graph();
        nodeSet = new Node[]{N1, N2, N3, N4, N5};
        for (int i = 0; i< 5; i++){
            nodeSet[i] = new Node("N"+i);
            g1.addNode(nodeSet[i]);
            g2.addNode(nodeSet[i]);
        }

    }

    @Test
    public void checkNodes(){
        assert (g1.getNumNodes() == 5);
    }

    @Test
    public void edgeTest(){
        e1 = new Edge(nodeSet[0],nodeSet[1], WEIGHTS.FIVE);
        e2 = new Edge(nodeSet[2],nodeSet[3], WEIGHTS.TWO);
        e3 = new Edge(nodeSet[3],nodeSet[4], WEIGHTS.ONE);
        g1.addEdge(e1);
        assert(g1.addEdge(e2));
        assert(g1.addEdge(e3));

    }
    @Test
    public void adjacencyListTest(){
        Edge e4 = new Edge(nodeSet[1],nodeSet[0], WEIGHTS.TWO);
        Edge e5 = new Edge(nodeSet[1],nodeSet[4], WEIGHTS.THREE);
        Edge e6 = new Edge(nodeSet[2],nodeSet[4], WEIGHTS.FIVE);
        Edge e7 = new Edge(nodeSet[3],nodeSet[2], WEIGHTS.FOUR);
        g2.addEdge(e4);
        g2.addEdge(e5);
        g2.addEdge(e6);
        g2.addEdge(e7);
        g2.setEdges();
        assert g2.getAdjacencyList().contains(e4);
    }

}
