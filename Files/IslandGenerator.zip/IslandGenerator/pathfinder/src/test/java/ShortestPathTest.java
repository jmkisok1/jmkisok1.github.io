import GraphOperations.ShortestPathBellmanFord;
import Identifiers.WEIGHTS;
import graphComponents.*;
import org.junit.jupiter.api.Test;

import java.util.*;

public class ShortestPathTest {
    Graph g;
    Node n1, n2, n3, n4, n5, n6;
    Edge e1, e2, e3, e4 ,e5, e6, e7;
    List<Node> shorts;
    ShortestPathBellmanFord ford;

    public ShortestPathTest(){
        g = new Graph();
        n1 = new Node(1);
        n2 = new Node(2);
        n3 = new Node(3);
        n4 = new Node(4);
        n5 = new Node(5);
        n6 = new Node(6);
        ford = new ShortestPathBellmanFord();
        g.addNode(n1);
        g.addNode(n2);
        g.addNode(n3);
        g.addNode(n4);
        g.addNode(n5);
        g.addNode(n6);
    }

    @Test
    public void testBellmanFord(){
        e1 = new Edge(n1,n2, WEIGHTS.TWO);
        e2 = new Edge(n1,n3, WEIGHTS.FOUR);
        e3 = new Edge(n3,n6, WEIGHTS.TWO);
        e4 = new Edge(n2, n4, WEIGHTS.ONE);
        e5 = new Edge(n2, n5, WEIGHTS.THREE);
        e6 = new Edge(n4,n5, WEIGHTS.FIVE);
        e7 = new Edge(n5,n6, WEIGHTS.THREE);
        g.addEdge(e1);
        g.addEdge(e2);
        g.addEdge(e3);
        g.addEdge(e4);
        g.addEdge(e5);
        g.addEdge(e6);
        g.addEdge(e7);
        g.setEdges();
        shorts = ford.findPath(g,n2, n6);
        assert shorts.get(0).equals(n6);
        assert shorts.get(1).equals(n5);
        assert shorts.get(2).equals(n2);
        printPathForTest(shorts,n2,n6);
    }

    public static void printPathForTest(List<Node> path, Node end, Node start){
        System.out.println("Path from " + end.getIdentifier() + " to " + start.getIdentifier() + " is: ");
        for (Node n:path) {
            System.out.print(n.getIdentifier() + " -> ");
        }
    }
}
