import Identifiers.STATUS;
import Identifiers.WEIGHTS;
import graphComponents.nullNode;
import org.junit.jupiter.api.Test;
import graphComponents.Node;
import graphComponents.Edge;


import java.io.IOException;
import java.util.ArrayList;

public class NodeEdgeTest {
    nullNode emptyNode;
    Node testNode1;
    Node testNode2;
    Edge edge;
    Node[] edgeArray;

    public NodeEdgeTest() throws IOException{
        emptyNode = new nullNode();
        testNode1 = new Node(1);
        testNode2 = new Node(2);
        edge = new Edge(testNode1,testNode2, WEIGHTS.ONE);
    }


    @Test
    public void checkNames(){
        assert(emptyNode.getIdentifier().equals("nullNodeID"));
        assert (testNode1.getIdentifier().equals("N1"));
        assert (testNode2.getIdentifier().equals("N2"));
    }

    @Test
    public void checkEdge(){
        assert (edge.getStartNode().equals(testNode1));
        assert (edge.getEndNode().equals(testNode2));
        assert(edge.getWeight().equals(WEIGHTS.ONE));
        assert (edge.weightToInteger() == 1);
    }

    @Test
    public void edgeArrayTest(){
        edgeArray = edge.getEdge();
        assert edgeArray[0].equals(testNode1);
        assert edgeArray[1].equals(testNode2);
    }
}
