package graphComponents;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;

import java.util.*;

public class Graph {
    private List<Node> nodes;
    private List<Edge> unsortedEdges;
    private List<Edge> adjacencyList;

    private int numNodes;
    private int numEdges;

    //Can create graph with edges and nodes
    public Graph(){
        numNodes =0;
        numEdges = 0;
        adjacencyList = new ArrayList<>();
        nodes = new ArrayList<>();
        unsortedEdges = new ArrayList<>();
    }



    public void setEdges(){
        adjacencyList = unsortedEdges;
        Collections.sort(adjacencyList);

    }
    public void addNode(Node n){
        nodes.add(n);
        Collections.sort(nodes);
        numNodes ++;
    }
    public Boolean addEdge(Edge e){
        unsortedEdges.add(e);
        //Automatically add (b,a) when (a,b) is added, to represent undirected graph
        unsortedEdges.add(new Edge(e.getEndNode(),e.getStartNode(),e.getWeight()));
        Collections.sort(unsortedEdges);
        numEdges++;
        return true;
    }

    public int getNumNodes(){
        return numNodes;
    }
    public List<Node> getNodes(){
        return nodes;
    }
    public Node get(int identifier){
        return nodes.get(identifier);
    }

    public List<Edge> getAdjacencyList(){
        return adjacencyList;
    }
}
