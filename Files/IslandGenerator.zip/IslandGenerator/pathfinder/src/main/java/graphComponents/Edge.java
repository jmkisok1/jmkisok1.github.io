package graphComponents;

import Identifiers.WEIGHTS;

import java.util.ArrayList;
import java.util.List;

public class Edge implements Comparable<Edge>{
    private List<Node> pair;
    private WEIGHTS weight;

    //Can make an edge from 2 existing nodes
    public Edge(Node n1, Node n2, WEIGHTS weight) {
        pair = new ArrayList<>();
        pair.add(n1);
        pair.add(n2);
        this.weight = weight;
    }

    public Node getStartNode(){
        try {
            return pair.get(0);
        }
        catch(IndexOutOfBoundsException E){
            throw new IndexOutOfBoundsException("Tried to get starting node from empty edge");
        }
    }
    public Node getEndNode(){
        try{
            return pair.get(1);
        }
        catch(IndexOutOfBoundsException E){
            throw new IndexOutOfBoundsException("Tried to get nonexistent end node from edge");
        }
    }
    public Node[] getEdge(){
        return pair.toArray(new Node[]{});
    }
    public WEIGHTS getWeight(){
        return weight;
    }
    public int weightToInteger(){
        return weight.ordinal();
    }

    @Override
    public int compareTo(Edge o) {
        return this.getStartNode().compareTo(o.getStartNode());
    }
}
