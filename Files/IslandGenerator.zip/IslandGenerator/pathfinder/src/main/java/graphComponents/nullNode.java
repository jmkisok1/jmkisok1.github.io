package graphComponents;

public class nullNode extends Node{

    public nullNode() {
        super("?");
    }
    @Override
    public String getIdentifier(){
        return ("nullNodeID");
    }
}
