package graphComponents;

public class Node implements Comparable<Node>{

    protected String identifier; //"Name" of the node, eg N1, N2 ... Nn
    private double x;
    private double y;

    public Node(int number){
        this.identifier = ("N"+ number);
        x=0;
        y=0;
    }
    public Node(String identifier){
        this.identifier = identifier;
        x=0;
        y=0;
    }
    public Node (double x, double y, int number){
        this.x = x;
        this.y = y;
        this.identifier = ("N"+number);
    }

    public String getIdentifier(){
        return identifier;
    }
    public int getNumber(){
        return Integer.parseInt(identifier.split("N")[1]);
    }
    public double[] getCoords(){
        return new double[]{this.x,this.y};
    }

    @Override
    public int compareTo(Node o) {
        if (this.getNumber() > o.getNumber()){
            return 1;
        }
        else if (this.getNumber() < o.getNumber()){
            return -1;
        }
        else{
            return 0;
        }
    }
}
