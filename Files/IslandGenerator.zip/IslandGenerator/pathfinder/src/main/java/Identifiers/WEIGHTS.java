package Identifiers;

public enum WEIGHTS {
    ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX
}
