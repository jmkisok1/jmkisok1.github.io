package Identifiers;

public enum STATUS {
    EMPTY, NO_CITY, COTTAGE, VILLAGE, HAMLET, TOWN, CAPITAL
}
