package GraphOperations;

import graphComponents.Graph;
import graphComponents.Node;

import java.util.*;

public interface ShortestPath {

    List<Node> findPath(Graph g, Node start, Node end);
}
