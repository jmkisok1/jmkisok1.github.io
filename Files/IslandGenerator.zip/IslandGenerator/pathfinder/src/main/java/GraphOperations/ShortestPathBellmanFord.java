package GraphOperations;

import graphComponents.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ShortestPathBellmanFord implements ShortestPath {

    public ShortestPathBellmanFord(){}
    @Override
    public List<Node> findPath(Graph g, Node start, Node end) {
        List<Node> path = new ArrayList<>();
        List<Integer> cost = new ArrayList<>();
        int numNodes = g.getNumNodes();
        if(start.equals(end)){
            path.add(start);
            return path;
        }

        //path = [? |n in N], cost = [inf | n in N]
        for (int i = 0; i< numNodes + 1; i++){
            path.add(new nullNode());
            cost.add(Integer.MAX_VALUE);
        }

        cost.set(start.getNumber(),0);
        path.set(start.getNumber(),start);

        int startpos, endpos;
        for (int j = 1; j <= numNodes -1; j++){{
                for(Edge e: g.getAdjacencyList()) {
                    startpos = e.getStartNode().getNumber();
                    endpos = e.getEndNode().getNumber();
                    //If cost[start node] + edge weight < cost [end node]:
                    if (cost.get(startpos) + e.weightToInteger() < cost.get(endpos) && cost.get(startpos) != Integer.MAX_VALUE) {
                        //Add end node to path list
                        path.set(endpos, e.getStartNode());
                        //Cost[end] = cost[start] + weight
                        cost.set(endpos, e.weightToInteger() + cost.get(startpos));
                    }
                }
            }
        }


        path = arrangePath(path, start, end);
        return path;
    }
    private static List<Node> arrangePath(List<Node> path, Node start, Node fin){
        //Returns a list of nodes from start to finish representing the shortest path
        //instead of the original list.
        List<Node> modPath = new ArrayList<>();
        modPath.add(fin);
        Node currentNode = path.get(fin.getNumber());
        modPath.add(currentNode);
        while (!currentNode.equals(start)){
            try {
                currentNode = path.get(currentNode.getNumber());
            }
            catch(ArrayIndexOutOfBoundsException E){
                break;
            }
            modPath.add(currentNode);
        }
        return trim(modPath);
    }
    private static List<Node> trim(List<Node> path){
        //Sometimes nullNodes are left at the end. Trim them.
        List<Node> trimmedPath = new ArrayList<>();
        for (Node n: path) {
            trimmedPath.add(n);
            if (n.getIdentifier().equals("nullNodeID")){
                break;
            }
        }
        return trimmedPath;
    }
}
