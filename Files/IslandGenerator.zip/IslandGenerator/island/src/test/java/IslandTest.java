import ca.mcmaster.cas.se2aa4.a2.io.MeshFactory;
import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.Config;
import island.tools.Islands.CircleIsland;
import island.tools.Islands.DonutIsland;
import island.tools.Islands.Island;
import island.tools.Islands.OvalIsland;
import island.tools.Specifier;
import island.tools.altimetricProfiles;
import island.tools.enricher.*;
import island.tools.render.RenderColor;
import island.tools.render.RenderShapes;
import island.tools.enricher.EnrichAquifer;
import island.tools.whittaker.DIAGRAMS;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;

public class IslandTest {
    Structs.Mesh aMesh;
    Island island;
    String outputFile;
    ArrayList<Object> methods = new ArrayList<>();

    public IslandTest() throws IOException {
        String[] args = {"-i", "src/test/java/Test.mesh", "-o", "src/test/java/Test.mesh", "-mode", "greenland"};
        Config config = new Config(args);
        this.aMesh = new MeshFactory().read(config.export("i"));
        this.island = new Specifier().specifier(config, aMesh);
        this.outputFile = config.export("o");
        methods.add(new RenderShapes());
        methods.add(new EnrichAltitude());
        methods.add(new EnrichBeaches());
        methods.add(new EnrichLakes());
        methods.add(new EnrichSoils());
        methods.add(new EnrichAquifer());
        methods.add(new RenderColor());
    }

    @Test
    public void islandIsCreated() {
        //Assert island was created without error
        assert (island != null);
    }

    @Test
    public void meshIsNotNull() {
        //Assert island is not null
        assert (island.getMesh() != null);
    }

    @Test
    public void elevationIsCorrect() {
        //Assert elevation is correct
        assert (island.getAltimetricProfile() == altimetricProfiles.ROLLING);
    }

    @Test
    public void aquifersAreCorrect() {
        //Assert aquifers are correct
        assert (island.getNumberOfAquifers() == 10);
    }

    @Test
    public void riversAreCorrect() {
        //Assert rivers are correct
        assert (island.getNumberOfRivers() == 5);
    }

   // @Test
    //public void lakesAreCorrect() {
      //  assert (island.getNumLakes() == 5);
    //}

    @Test
    public void diagramIsCorrect() {
        //Assert diagram is correct
        assert (island.getDiagram() == DIAGRAMS.ARCTIC);
    }

    @Test
    public void seedIsCorrect() {
        //Assert seed is a long
        assert (island.getSeed().getClass() == Long.class);
    }

    @Test
    public void shapeIsCorrect() {
        //Assert shape is correct
        assert (island instanceof OvalIsland);
    }

    @Test
    public void geometryIsCorrect() {
        //Assert geometry is correct
        if (island instanceof CircleIsland) {
            assert(((CircleIsland) island).getRadius() == 300);
        } else if (island instanceof DonutIsland) {
            assert(((DonutIsland) island).getInnerRadius() == 200);
            assert(((DonutIsland) island).getOuterRadius() == 300);
        } else if (island instanceof OvalIsland) {
            assert(((OvalIsland) island).getRadius() == 300);
        } else {
            assert(false);
        }
    }
    @Test
    public void islandIsModified() {
        //Assert island is modified for each method
        for (Object method : methods) {
            Structs.Mesh before = Structs.Mesh.newBuilder(aMesh).
                    addAllVertices(aMesh.getVerticesList()).
                    addAllSegments(aMesh.getSegmentsList()).
                    addAllPolygons(aMesh.getPolygonsList()).
                    build();
            if (method instanceof RenderShapes) {
                ((RenderShapes) method).render(island);
            } else if (method instanceof EnrichAltitude) {
                ((EnrichAltitude) method).enrich(island);
            } else if (method instanceof EnrichBeaches) {
                ((EnrichBeaches) method).enrich(island);
            } else if (method instanceof EnrichLakes) {
                ((EnrichLakes) method).enrich(island);
            } else if (method instanceof EnrichSoils){
                ((EnrichSoils) method).enrich(island);
            } else if (method instanceof EnrichAquifer) {
                ((EnrichAquifer) method).enrich(island);
//            } else if (method instanceof RenderColor) {
//                ((RenderColor) method).render(island);
            }
            Structs.Mesh after = island.getMesh();
            //Assert mesh was changed
            assert(before != after);
        }
    }

    @Test
    public void meshIsWritten() {
        //Assert mesh was written without error
        try {
            new MeshFactory().write(island.getMesh(), outputFile);
            assert (true);
        } catch (IOException e) {
            assert (false);
        }
    }
}