import ca.mcmaster.cas.se2aa4.a2.io.*;
import island.tools.*;
import island.tools.Adt.*;
import island.tools.GraphConversion.GraphConverter;
import island.tools.GraphConversion.MakePath;
import island.tools.Islands.*;
import island.tools.enricher.*;
import island.tools.render.RenderColor;
import island.tools.Specifier;
import island.tools.render.RenderShapes;
import island.tools.whittaker.DIAGRAMS;

public class Main {
    public static void main(String[] args) throws Exception {

        Config config = new Config(args);
        Structs.Mesh aMesh = new MeshFactory().read(config.export("i"));
        Island island = new Specifier().specifier(config, aMesh);
        System.out.println("Input: " + config.export("i"));
        System.out.println("Output: " + config.export("o"));
        System.out.println("Mode: " + config.export("mode"));
        System.out.println("Climate: " + island.getDiagram());
        System.out.println("Altitude: " + island.getAltimetricProfile());
        System.out.println("Aquifers: " + island.getNumberOfAquifers());
        System.out.println("Soil type: " + island.getSoilLevel());
        System.out.println("Seed: "+island.getSeed());
        Mesh newMesh = new EnrichedMeshBuilder().build(aMesh,island.getNumCities());
        new RenderShapes().render(island);
        new EnrichAltitude().enrich(island);
        new EnrichLakes().enrich(island);
        new EnrichSoils().enrich(island);
        new EnrichAquifer().enrich(island);
        new EnrichHumidity().enrich(island);
        if (island.getDiagram().equals(DIAGRAMS.TROPICAL)) {
            new EnrichTropical().enrich(island);
        }
        else {
            new EnrichArctic().enrich(island);
        }
        new GraphConverter().convert(newMesh);
        island.setMesh(new MakePath().makePaths(newMesh,island.getMesh()));
        new RenderColor().render(island);
        new MeshFactory().write(island.getMesh(), config.export("o"));
    }
}