package island.tools.checker;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;

public interface CheckSegmentKeys {
    int findKey(Structs.Segment s,String id);
}
