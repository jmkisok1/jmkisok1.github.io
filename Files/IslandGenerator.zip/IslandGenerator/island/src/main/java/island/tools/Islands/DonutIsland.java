package island.tools.Islands;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.altimetricProfiles;
import island.tools.whittaker.DIAGRAMS;

public class DonutIsland extends Island {
    private final int outer_radius;
    private final int inner_radius;


    public DonutIsland(Structs.Mesh mesh, altimetricProfiles profile, int numberOfAquifers, int numberOfRivers, DIAGRAMS diagram, Long seed, int outer_radius, int inner_radius, int soil,int numLakes, int numCities) {
        super(mesh, profile, numberOfAquifers, numberOfRivers, diagram, seed, soil, numLakes, numCities);
        this.outer_radius = outer_radius;
        this.inner_radius = inner_radius;
    }

    public int getOuterRadius() {
        return outer_radius;
    }
    public int getInnerRadius() {
        return inner_radius;
    }

}
