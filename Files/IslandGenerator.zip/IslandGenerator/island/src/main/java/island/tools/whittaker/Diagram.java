package island.tools.whittaker;

import island.tools.BIOMES;

public interface Diagram {
    //Diagrams class has Whittaker diagrams that return a biome based on elevation and humidity inputs.
    public BIOMES getBiome(int humidity, int altitude);
}
