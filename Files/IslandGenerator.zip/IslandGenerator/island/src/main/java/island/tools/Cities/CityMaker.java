package island.tools.Cities;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.Adt.Mesh;

import java.util.List;

public interface CityMaker{
    void placeRandomCities(int numCities, Structs.Mesh aMesh, Mesh myMesh);
}
