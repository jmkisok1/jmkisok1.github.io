package island.tools.checker;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;

public interface CheckVertexKeys {
    int findKey(Structs.Vertex v, String id);
}
