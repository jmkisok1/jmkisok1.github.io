package island.tools.enricher;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.BIOMES;
import island.tools.Islands.Island;
import island.tools.checker.GetBiome;

public class EnrichSoils implements Enricher{


    @Override
    public void enrich(Island island) {
        //Sets soil absorption properties that are used to get humidity later
        Structs.Mesh.Builder copy = Structs.Mesh.newBuilder();
        copy.addAllSegments(island.getMesh().getSegmentsList());
        copy.addAllVertices(island.getMesh().getVerticesList());
        GetBiome getter = new GetBiome();
        int index;
        for (Structs.Polygon P: island.getMesh().getPolygonsList()) {
            index = getter.findKey(P);
            //For non-water provinces, give absorption property equal to that saved in the Island
            if (!P.getProperties(index).getValue().equals(BIOMES.OCEAN.toString()) && !P.getProperties(index).getValue().equals(BIOMES.LAKE.toString())){
                Structs.Property absorption = Structs.Property.newBuilder().setKey("soil").setValue(String.valueOf(island.getSoilLevel())).build();
                Structs.Polygon.Builder builder = Structs.Polygon.newBuilder(P);
                builder.addProperties(absorption);
                P = builder.build();
            }
            //Water tiles have absorption of 0 for simplicity
            else{
                Structs.Property absorption = Structs.Property.newBuilder().setKey("soil").setValue("0").build();
                Structs.Polygon.Builder builder = Structs.Polygon.newBuilder(P);
                builder.addProperties(absorption);
                P = builder.build();
            }
            copy.addPolygons(P);

        }
        island.setMesh(copy.build());
    }
}
