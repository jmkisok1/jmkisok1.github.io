package island.tools.enricher;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.BIOMES;
import island.tools.Islands.CircleIsland;
import island.tools.Islands.DonutIsland;
import island.tools.Islands.Island;
import island.tools.Islands.OvalIsland;
import island.tools.checker.GetBiome;

import java.util.List;


public class EnrichBeaches implements Enricher {

    @Override
    public void enrich(Island island) {
        Structs.Mesh aMesh = island.getMesh();
        Structs.Mesh.Builder clone = Structs.Mesh.newBuilder();
        clone.addAllSegments(aMesh.getSegmentsList());
        clone.addAllVertices(aMesh.getVerticesList());
        GetBiome getter = new GetBiome();
        int biomeIndex;
        for (Structs.Polygon poly : aMesh.getPolygonsList()) {
            for (int neighbor_idx : poly.getNeighborIdxsList()) {
                biomeIndex = getter.findKey(poly);
                if (poly.getProperties(biomeIndex).getValue().equals(BIOMES.LAND.toString()) && (aMesh.getPolygons(neighbor_idx).getProperties(biomeIndex).getValue().equals(BIOMES.OCEAN.toString()))) {
                    Structs.Property biome = Structs.Property.newBuilder().setKey("biome").setValue(BIOMES.BEACH.toString()).build();
                    Structs.Polygon.Builder polyBuilder = Structs.Polygon.newBuilder(poly);
                    polyBuilder.clearProperties();
                    polyBuilder.addAllProperties(poly.getPropertiesList());
                    polyBuilder.addProperties(biome);
                    poly = polyBuilder.build();
                }
                clone.addPolygons(poly);
            }
        }
        island.setMesh(clone.build());
    }
}

