package island.tools.enricher;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.BIOMES;
import island.tools.Islands.Island;
import island.tools.checker.GetAquafier;
import island.tools.checker.GetBiome;

import java.util.ArrayList;
import java.util.List;

public class EnrichHumidity implements Enricher {
    //Class to give humidities to land tiles based on proximities to aquifers and lakes, and soil absorption.
    @Override
    public void enrich(Island island) {
        Structs.Mesh aMesh = island.getMesh();
        Structs.Mesh.Builder copy = Structs.Mesh.newBuilder();
        //Make a copy of the mesh
        copy.addAllSegments(aMesh.getSegmentsList());
        copy.addAllVertices(aMesh.getVerticesList());
        GetBiome biome_getter = new GetBiome();
        GetAquafier aquafier_getter = new GetAquafier();
        int biomeIndex;
        int aquiferIndex;
        int humidity_multi = island.getSoilLevel();

        //Lists for storing polygons
        List<Integer> visited5 = new ArrayList<>();
        List<Integer> visited4 = new ArrayList<>();
        List<Integer> visited3 = new ArrayList<>();
        List<Integer> visited2 = new ArrayList<>();
        List<Integer> visited1 = new ArrayList<>();
        List<Structs.Polygon> humidify5 = new ArrayList<>();
        List<Structs.Polygon> humidify4 = new ArrayList<>();
        List<Structs.Polygon> humidify3 = new ArrayList<>();
        List<Structs.Polygon> humidify2 = new ArrayList<>();
        List<Structs.Polygon> humidify1 = new ArrayList<>();

        //adds all land polygon indexes that are next to lake or aquifer to a list
        for (Structs.Polygon poly : aMesh.getPolygonsList()) {
            biomeIndex = biome_getter.findKey(poly);
            if ((poly.getProperties(biomeIndex).getValue().equals(BIOMES.LAKE.toString()))) {
                for (int neighbor_idx : poly.getNeighborIdxsList()) {
                    Structs.Polygon P = aMesh.getPolygons(neighbor_idx);
                    biomeIndex = biome_getter.findKey(P);
                    aquiferIndex = aquafier_getter.findKey(P);
                    if (!P.getProperties(biomeIndex).getValue().equals(BIOMES.LAKE.toString()) && !P.getProperties(biomeIndex).getValue().equals(BIOMES.OCEAN.toString()) && !P.getProperties(aquiferIndex).getValue().equals("true") && (!visited5.contains(neighbor_idx))&& (!visited4.contains(neighbor_idx))) {
                        visited5.add(neighbor_idx);
                    }
                }
            }
        }
        //gets polygons from index's in visited 5
        for (int index : visited5) {
            humidify5.add(aMesh.getPolygons(index));
        }
        //repeats process to get assign polygons humidity of 4 if they are next to a polygon of humidity 5,assigns 3 if they are next to polygon of humidity 4 etc.
        for (Structs.Polygon poly : humidify5) {
            for (int neighbor_idx : poly.getNeighborIdxsList()) {
                Structs.Polygon P = aMesh.getPolygons(neighbor_idx);

                biomeIndex = biome_getter.findKey(P);
                aquiferIndex = aquafier_getter.findKey(P);
                if (!P.getProperties(biomeIndex).getValue().equals(BIOMES.LAKE.toString()) && !P.getProperties(biomeIndex).getValue().equals(BIOMES.OCEAN.toString()) && !P.getProperties(aquiferIndex).getValue().equals("true") && (!visited5.contains(neighbor_idx))) {
                    visited4.add(neighbor_idx);
                }

            }

        }

        for (int index : visited4) {
            humidify4.add(aMesh.getPolygons(index));
        }

        for (Structs.Polygon poly : humidify4) {
            for (int neighbor_idx : poly.getNeighborIdxsList()) {
                Structs.Polygon P = aMesh.getPolygons(neighbor_idx);
                biomeIndex = biome_getter.findKey(P);
                aquiferIndex = aquafier_getter.findKey(P);
                if (!P.getProperties(biomeIndex).getValue().equals(BIOMES.LAKE.toString()) && !P.getProperties(biomeIndex).getValue().equals(BIOMES.OCEAN.toString()) && !P.getProperties(aquiferIndex).getValue().equals("true") && (!visited5.contains(neighbor_idx)) && !visited4.contains(neighbor_idx) && !visited3.contains(neighbor_idx)) {
                    visited3.add(neighbor_idx);
                }
            }
        }

        for (int index : visited3) {
            humidify3.add(aMesh.getPolygons(index));
        }

        for (Structs.Polygon poly : humidify3) {
            for (int neighbor_idx : poly.getNeighborIdxsList()) {
                Structs.Polygon P = aMesh.getPolygons(neighbor_idx);
                biomeIndex = biome_getter.findKey(P);
                aquiferIndex = aquafier_getter.findKey(P);
                if (!P.getProperties(biomeIndex).getValue().equals(BIOMES.LAKE.toString()) && !P.getProperties(biomeIndex).getValue().equals(BIOMES.OCEAN.toString()) && !P.getProperties(aquiferIndex).getValue().equals("true") && (!visited5.contains(neighbor_idx)) && !visited4.contains(neighbor_idx) && !visited3.contains(neighbor_idx) && !visited2.contains(neighbor_idx)) {
                    visited2.add(neighbor_idx);
                }
            }
        }

        for (int index : visited2) {
            humidify2.add(aMesh.getPolygons(index));
        }

        for (Structs.Polygon poly : humidify2) {
            for (int neighbor_idx : poly.getNeighborIdxsList()) {
                Structs.Polygon P = aMesh.getPolygons(neighbor_idx);
                biomeIndex = biome_getter.findKey(P);
                aquiferIndex = aquafier_getter.findKey(P);
                if (!P.getProperties(biomeIndex).getValue().equals(BIOMES.LAKE.toString()) && !P.getProperties(biomeIndex).getValue().equals(BIOMES.OCEAN.toString()) && !P.getProperties(aquiferIndex).getValue().equals("true") && (!visited5.contains(neighbor_idx)) && !visited4.contains(neighbor_idx) && !visited3.contains(neighbor_idx) && !visited2.contains(neighbor_idx) && !visited1.contains(neighbor_idx)) {
                    visited1.add(neighbor_idx);
                }
            }
        }

        for (int index : visited1) {
            humidify1.add(aMesh.getPolygons(index));
        }
        //assigns all lists of polygons their humidity values and sets islands to mesh to include these humidity values.
        for (Structs.Polygon poly : aMesh.getPolygonsList()) {
            if (humidify5.contains(poly)) {
                Structs.Property humidity = Structs.Property.newBuilder().setKey("humidity").setValue(String.valueOf((humidity_multi * 5))).build();
                Structs.Polygon.Builder builder = Structs.Polygon.newBuilder(poly);
                builder.addProperties(humidity);
                poly = builder.build();
            } else if (humidify4.contains(poly)) {
                Structs.Property humidity = Structs.Property.newBuilder().setKey("humidity").setValue(String.valueOf((humidity_multi * 4))).build();
                Structs.Polygon.Builder builder = Structs.Polygon.newBuilder(poly);
                builder.addProperties(humidity);
                poly = builder.build();
            } else if (humidify3.contains(poly)) {
                Structs.Property humidity = Structs.Property.newBuilder().setKey("humidity").setValue(String.valueOf((humidity_multi * 3))).build();
                Structs.Polygon.Builder builder = Structs.Polygon.newBuilder(poly);
                builder.addProperties(humidity);
                poly = builder.build();
            } else if (humidify2.contains(poly)) {
                Structs.Property humidity = Structs.Property.newBuilder().setKey("humidity").setValue(String.valueOf((humidity_multi * 2))).build();
                Structs.Polygon.Builder builder = Structs.Polygon.newBuilder(poly);
                builder.addProperties(humidity);
                poly = builder.build();
            } else if (humidify1.contains(poly)) {
                Structs.Property humidity = Structs.Property.newBuilder().setKey("humidity").setValue(String.valueOf((humidity_multi))).build();
                Structs.Polygon.Builder builder = Structs.Polygon.newBuilder(poly);
                builder.addProperties(humidity);
                poly = builder.build();
            } else {
                Structs.Property humidity = Structs.Property.newBuilder().setKey("humidity").setValue("0").build();
                Structs.Polygon.Builder builder = Structs.Polygon.newBuilder(poly);
                builder.addProperties(humidity);
                poly = builder.build();
            }
            copy.addPolygons(poly);
        }
        island.setMesh(copy.build());
    }
}
