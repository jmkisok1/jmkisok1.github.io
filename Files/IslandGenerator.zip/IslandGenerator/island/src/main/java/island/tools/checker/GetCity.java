package island.tools.checker;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;

import java.util.List;

public class GetCity implements CheckVertexKeys{

    @Override
    public int findKey(Structs.Vertex v, String id) {
        List<Structs.Property> propList = v.getPropertiesList();
        for (int i = 0; i < propList.size(); i++){
            if (propList.get(i).getKey().equals(id)){
                return i;
            }
        }
        return -1;
    }
}
