package island.tools.enricher;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.BIOMES;
import island.tools.Islands.Island;
import island.tools.checker.GetBiome;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class EnrichLakes implements Enricher{


    @Override
    public void enrich(Island island) {
        //Makes random land tiles into lakes by switching biome properties.
        Random randy = new Random();
        randy.setSeed(island.getSeed());
        //Make a copy of the mesh
        Structs.Mesh aMesh = island.getMesh();
        Structs.Mesh.Builder copy = Structs.Mesh.newBuilder();
        copy.addAllSegments(aMesh.getSegmentsList());
        copy.addAllVertices(aMesh.getVerticesList());

        GetBiome getter = new GetBiome();
        int random;
        int biomeIndex;
        int numLakes = island.getNumLakes();
        int counter = 0;
        //List for holding new lake polygons
        List<Structs.Polygon> lakes = new ArrayList<>();
        //Each polygon is considered and if it is land, it has a random chance to be given the lake biome instead.
        //In case not enough lakes are made (since it is random), this can loop.
        while (counter < numLakes) {
            for (Structs.Polygon poly : aMesh.getPolygonsList()) {
                for (int neighbor_idx : poly.getNeighborIdxsList()) {
                    biomeIndex = getter.findKey(poly);
                    //Don't add ocean tiles or land bordering ocean tiles to the lakes list.
                    if (poly.getProperties(biomeIndex).getValue().equals(BIOMES.LAND.toString()) && !(aMesh.getPolygons(neighbor_idx).getProperties(biomeIndex).getValue().equals(BIOMES.OCEAN.toString())) && (counter < numLakes)) {
                        random = randy.nextInt(0, 5);
                        if (random == 4) {
                            counter++;
                            Structs.Property biome = Structs.Property.newBuilder().setKey("biome").setValue(BIOMES.LAKE.toString()).build();
                            Structs.Polygon.Builder polyBuilder = Structs.Polygon.newBuilder(poly);
                            polyBuilder.clearProperties();
                            polyBuilder.addProperties(biome);
                            for (Structs.Property prop : poly.getPropertiesList()) {
                                //Don't add the old LAND biome property
                                if (!prop.getKey().equals("biome")) {
                                    polyBuilder.addProperties(prop);
                                }
                            }
                            poly = polyBuilder.build();
                            lakes.add(poly);
                        }
                    }
                }
            }
        }
        //Add new lakes and old polygons to the copy mesh
        for (Structs.Polygon poly : aMesh.getPolygonsList()){
            if (!lakes.contains(poly)){
                copy.addPolygons(poly);
            }
        }
        for(Structs.Polygon poly : lakes){
            copy.addPolygons(poly);
        }
        island.setMesh(copy.build());
    }
}
