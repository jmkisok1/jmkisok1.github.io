package island.tools.checker;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;

import java.util.List;

public class GetSoil implements CheckKeys{
    public GetSoil(){}

    @Override
    public int findKey(Structs.Polygon polygon) {
        List<Structs.Property> properties = polygon.getPropertiesList();
        for (int index = 0; index < properties.size();index++) {
            if (properties.get(index).getKey().equals("soil")){
                return index;
            }
        }
        throw new IllegalArgumentException("No key found");
    }
}
