package island.tools.Adt;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.Cities.MakeCities;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EnrichedMeshBuilder {
    //A new Mesh ADT that was supposed to make my life easier.
    public EnrichedMeshBuilder(){}

    public Mesh build(Structs.Mesh aMesh, int numCities) {
        Mesh newMesh = new Mesh();
        newMesh.setSegments(makeSegs(aMesh.getSegmentsList(),aMesh.getVerticesList()));
        newMesh.setVertices(makeVertices(aMesh.getVerticesList()));
        new MakeCities().placeRandomCities(numCities,aMesh, newMesh);
        return newMesh;
    }

    private static Set<Segment> makeSegs(List<Structs.Segment> segmentList, List<Structs.Vertex> vertices) {
        Set<Segment> enrichedSegments = new HashSet<>();
        for(Structs.Segment s : segmentList){
            Structs.Vertex v1 = vertices.get(s.getV1Idx());
            Structs.Vertex v2 = vertices.get(s.getV2Idx());
            Segment sNew = new Segment(v1,v2);
            enrichedSegments.add(sNew);
        }
        return enrichedSegments;
    }

    private static List<Vertex> makeVertices(List<Structs.Vertex> vertexList){
        List<Vertex> enrichedVertices = new ArrayList<>();
        for (Structs.Vertex v: vertexList){
            Vertex vNew = new Vertex(v);
            enrichedVertices.add(vNew);
        }
        return enrichedVertices;
    }
}
