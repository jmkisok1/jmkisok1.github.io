package island.tools.checker;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;

public interface CheckKeys {
     //Since properties aren't ordered in polygons, the findKey interface is used to quickly find the right keys for a property.
     int findKey(Structs.Polygon polygon);
}
