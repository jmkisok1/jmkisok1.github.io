package island.tools;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.Islands.CircleIsland;
import island.tools.Islands.DonutIsland;
import island.tools.Islands.Island;
import island.tools.Islands.OvalIsland;
import island.tools.whittaker.DIAGRAMS;

import java.util.Random;

public class Specifier {

    public Island specifier(Config config, Structs.Mesh aMesh) {
        Random seedGenerator = new Random();

        //if going by mode
        try {
            if (config.export("mode").equals("lagoon"))
                return new DonutIsland(aMesh, altimetricProfiles.RANDOM, 10, 5, DIAGRAMS.TROPICAL, seedGenerator.nextLong(), 300, 200,3,0,10);
            else if (config.export("mode").equals("greenland"))
                return new OvalIsland(aMesh, altimetricProfiles.ROLLING, 10, 5, DIAGRAMS.ARCTIC, seedGenerator.nextLong(), 300, 2,5,10);
            else if (config.export("mode").equals("volcano"))
                return new CircleIsland(aMesh, altimetricProfiles.VOLCANO, 10, 5, DIAGRAMS.TROPICAL, seedGenerator.nextLong(), 300, 1,5,10);
        } catch (Exception ignored) {}

        //Get elevation profile
        altimetricProfiles profile = altimetricProfiles.RANDOM;
        try {
            if (config.export("shape").equals("dount")) profile = altimetricProfiles.RANDOM;
            else if (config.export("altitude").equals("random")) profile = altimetricProfiles.RANDOM;
            else if (config.export("altitude").equals("rolling")) profile = altimetricProfiles.ROLLING;
            else if (config.export("altitude").equals("volcano")) profile = altimetricProfiles.VOLCANO;
        } catch (Exception ignored) {}

        //Get number of aquifers
        int numberOfAquifers = 0;
        try {
            numberOfAquifers = Integer.parseInt(config.export("aquifer"));
        } catch (NumberFormatException ignored) {}
        if (numberOfAquifers < 0) numberOfAquifers = 0;

        //Get number of rivers
        int numberOfRivers = 0;
        try {
            numberOfRivers = Integer.parseInt(config.export("rivers"));
        } catch (NumberFormatException ignored) {}
        if (numberOfRivers < 0) numberOfRivers = 0;

        //Get absorption level for land tiles
        int soilAbsorption = 1;
        try{
            soilAbsorption= Integer.parseInt(config.export("soil"));
        } catch (Exception ignored){}
        if (soilAbsorption < 1 || soilAbsorption > 3) soilAbsorption = 1;

        //Get whittaker diagram
        DIAGRAMS diagram = DIAGRAMS.ARCTIC;
        try {
            diagram = DIAGRAMS.valueOf(config.export("biomes").toUpperCase());
        } catch (Exception ignored) {}

        //Get seed
        long seed = seedGenerator.nextLong();
        try {
                seed = Long.parseLong(config.export("seed"));
        } catch (NumberFormatException ignored) {}

        //Get number of lakes
        int numLakes = 0;
        try{
            numLakes = Integer.parseInt(config.export("lakes"));
        } catch(Exception ignored){}
        if (numLakes < 0) numLakes = 0;

        int numCities = 5;
        try{
            numCities = Integer.parseInt(config.export("cities"));
        }
        catch(Exception ignored){}


        //set shapes
        if (config.export("shape").equals("circle")) return new CircleIsland(aMesh, profile, numberOfAquifers, numberOfRivers, diagram, seed, 300, soilAbsorption, numLakes,numCities);
        else if (config.export("shape").equals("donut")) return new DonutIsland(aMesh, profile, numberOfAquifers, numberOfRivers, diagram, seed, 300, 200, soilAbsorption, numLakes,numCities);
        else if (config.export("shape").equals("oval")) return new OvalIsland(aMesh, profile, numberOfAquifers, numberOfRivers, diagram, seed, 300, soilAbsorption, numLakes,numCities);
        else return new CircleIsland(aMesh,profile,numberOfAquifers,numberOfRivers,diagram,seed,300,soilAbsorption,numLakes,numCities);
    }
}
