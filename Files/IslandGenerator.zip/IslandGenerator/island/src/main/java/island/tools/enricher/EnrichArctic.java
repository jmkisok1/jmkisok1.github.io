package island.tools.enricher;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.BIOMES;
import island.tools.Islands.Island;
import island.tools.checker.GetBiome;
import island.tools.checker.GetElevation;
import island.tools.checker.GetHumidity;
import island.tools.whittaker.*;

public class EnrichArctic implements Enricher{
    //Same as enrichTropical but for the arctic diagram

    @Override
    public void enrich(Island island) {
        Structs.Mesh aMesh = island.getMesh();
        Structs.Mesh.Builder clone = Structs.Mesh.newBuilder(aMesh);
        clone.addAllSegments(aMesh.getSegmentsList());
        clone.addAllVertices(aMesh.getVerticesList());
        int humidityValue;
        int ElevationValue;
        int elevKey, humidiKey, biomeKey;
        Arctic arctic = new Arctic();
        BIOMES currentBiome;
        GetElevation getElevation = new GetElevation();
        GetHumidity getHumidity = new GetHumidity();
        GetBiome getBiome =new GetBiome();
        for (Structs.Polygon P: aMesh.getPolygonsList()) {
            elevKey = getElevation.findKey(P);
            humidiKey = getHumidity.findKey(P);
            biomeKey = getBiome.findKey(P);
            ElevationValue = Integer.parseInt(P.getProperties(elevKey).getValue());
            humidityValue = Integer.parseInt(P.getProperties(humidiKey).getValue());
            if (P.getProperties(biomeKey).getValue().equals(BIOMES.LAND.toString())) {
                currentBiome = arctic.getBiome(humidityValue, ElevationValue);
                Structs.Property prop = Structs.Property.newBuilder().setKey("biome").setValue(currentBiome.name()).build();
                Structs.Polygon.Builder builder = Structs.Polygon.newBuilder(P);
                builder.clearProperties();
                builder.addProperties(prop);
                P = builder.build();
            }
            clone.addPolygons(P);

        }
        island.setMesh(clone.build());
    }
}
