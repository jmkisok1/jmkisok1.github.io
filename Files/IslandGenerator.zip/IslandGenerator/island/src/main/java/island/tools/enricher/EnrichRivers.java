package island.tools.enricher;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.Islands.Island;
import island.tools.checker.GetBiome;

import java.util.Random;

public class EnrichRivers implements Enricher {
    @Override
    public void enrich(Island island) {
        //Does not make rivers. We know.
        Random random = new Random();
        random.setSeed(island.getSeed());
        Structs.Mesh aMesh = island.getMesh();
        Structs.Mesh.Builder clone = Structs.Mesh.newBuilder();
        clone.addAllSegments(aMesh.getSegmentsList());
        clone.addAllVertices(aMesh.getVerticesList());
        GetBiome getter = new GetBiome();

        int river_count = island.getNumberOfRivers();

        for (int i = 0; i < river_count; i++){
            int randomIndex = random.nextInt(aMesh.getPolygonsCount());
            Structs.Polygon polygon = aMesh.getPolygons(randomIndex);
            String biome = polygon.getPropertiesList().get(getter.findKey(polygon)).getValue();
            if (biome.equals("OCEAN")) {
                continue;
            }
            Structs.Segment segment = aMesh.getSegments(polygon.getSegmentIdxs(0));
            Structs.Property river = Structs.Property.newBuilder().setKey("river").setValue("true").build();
            Structs.Segment river_segment = segment.toBuilder().addProperties(river).build();
            clone.addSegments(river_segment);
        }
        island.setMesh(clone.build());
    }
}
