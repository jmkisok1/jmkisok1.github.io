package island.tools;

public enum BIOMES {
    OCEAN, LAND, LAKE, BEACH,
    //Arctic
    TUNDRA, TAIGA, BOREAL_FOREST, ALPINE_TUNDRA, ALPINE_TAIGA, ALPINE_FOREST,
    //Tropical
    DESERT, SAVANNA, GRASSLAND, WOODLAND, TROPICAL_FOREST, TROPICAL_RAINFOREST,
    //Just in case
    NOP
}
