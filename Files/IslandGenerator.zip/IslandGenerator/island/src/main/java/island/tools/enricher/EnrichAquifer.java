package island.tools.enricher;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.BIOMES;
import island.tools.Islands.Island;
import island.tools.checker.GetAquafier;
import island.tools.checker.GetBiome;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class EnrichAquifer implements Enricher {
    @Override
    public void enrich(Island island) {
        //Makes aquifers randomly by assigning this property to land tiles.
        Structs.Mesh aMesh = island.getMesh();
        Structs.Mesh.Builder clone = Structs.Mesh.newBuilder();
        clone.addAllSegments(aMesh.getSegmentsList());
        clone.addAllVertices(aMesh.getVerticesList());

        int numberOfAquifers = island.getNumberOfAquifers();

        Random random = new Random();
        random.setSeed(island.getSeed());
        GetBiome getter = new GetBiome();
        int counter = 0;
        for (Structs.Polygon poly : aMesh.getPolygonsList()) {
            Structs.Property aquifer;
            if ((counter < numberOfAquifers) && poly.getProperties(getter.findKey(poly)).getValue().equals(BIOMES.LAND.toString())) {
                aquifer = Structs.Property.newBuilder().setKey("aquifer").setValue("true").build();
                counter++;
            } else {
                aquifer = Structs.Property.newBuilder().setKey("aquifer").setValue("false").build();
            }
            Structs.Polygon.Builder polyBuilder = Structs.Polygon.newBuilder(poly);
            polyBuilder.clearProperties();
            polyBuilder.addProperties(aquifer);
            polyBuilder.addAllProperties(poly.getPropertiesList());
            poly = polyBuilder.build();
            clone.addPolygons(poly);
        }
        Structs.Mesh newMesh = clone.build();
        island.setMesh(newMesh);
    }
}
