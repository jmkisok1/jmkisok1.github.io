package island.tools.render;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.BIOMES;
import island.tools.Islands.CircleIsland;
import island.tools.Islands.DonutIsland;
import island.tools.Islands.Island;
import island.tools.Islands.OvalIsland;

public class RenderShapes implements Renderable {
    //Class for making basic "land" and "ocean" tiles in one of 3 shapes.
    //Gives polygons a biome property for land or ocean to do this.

    public void render(Island island) {
        if (island instanceof CircleIsland) {
            render((CircleIsland) island);
        } else if (island instanceof DonutIsland) {
            render((DonutIsland) island);
        } else if (island instanceof OvalIsland) {
            render((OvalIsland) island);
        }
    }

    public void render(DonutIsland island) {
        //Uses an inner and outer radius to make a donut-shaped island.
        final int outer_radius = island.getOuterRadius();
        final int inner_radius = island.getInnerRadius();
        Structs.Mesh aMesh = island.getMesh();
        //get max x value from mesh
        double maxX = 0;
        for (Structs.Vertex vertex : aMesh.getVerticesList()) {
            if (vertex.getX() > maxX) maxX = vertex.getX();
        }
        //get max y value from mesh
        double maxY = 0;
        for (Structs.Vertex vertex : aMesh.getVerticesList()) {
            if (vertex.getY() > maxY) maxY = vertex.getY();
        }
        Structs.Mesh.Builder clone = Structs.Mesh.newBuilder();
        clone.addAllVertices(aMesh.getVerticesList());
        clone.addAllSegments(aMesh.getSegmentsList());
        for (Structs.Polygon polygon : aMesh.getPolygonsList()) {
            double[] point = {aMesh.getVerticesList().get(polygon.getCentroidIdx()).getX(), aMesh.getVerticesList().get(polygon.getCentroidIdx()).getY()};
            Structs.Polygon.Builder poly = Structs.Polygon.newBuilder(polygon);
            Structs.Property color;
            if (Math.sqrt(Math.pow(point[0] - maxX/2, 2) + Math.pow(point[1] - maxY/2, 2)) <= outer_radius &&
                    Math.sqrt(Math.pow(point[0] - maxX/2, 2) + Math.pow(point[1] - maxY/2, 2)) >= inner_radius) {
                //set poly to land
                color = Structs.Property.newBuilder()
                        .setKey("biome")
                        .setValue(BIOMES.LAND.toString())
                        .build();
            } else if (Math.sqrt(Math.pow(point[0] - maxX/2, 2) + Math.pow(point[1] - maxY/2, 2)) <= outer_radius) {
                //set poly to lake
                color = Structs.Property.newBuilder()
                        .setKey("biome")
                        .setValue(BIOMES.LAKE.toString())
                        .build();
            } else {
                //set poly to ocean
                color = Structs.Property.newBuilder()
                        .setKey("biome")
                        .setValue(BIOMES.OCEAN.toString())
                        .build();
            }
            poly.addProperties(color);
            clone.addPolygons(poly);
        }
        island.setMesh(clone.build());
    }


    public void render(CircleIsland island) {
        //makes a centred circle with some radius.
        final int radius = island.getRadius();
        Structs.Mesh aMesh = island.getMesh();
        //get max x value from mesh
        double maxX = 0;
        for (Structs.Vertex vertex : aMesh.getVerticesList()) {
            if (vertex.getX() > maxX) maxX = vertex.getX();
        }
        //get max y value from mesh
        double maxY = 0;
        for (Structs.Vertex vertex : aMesh.getVerticesList()) {
            if (vertex.getY() > maxY) maxY = vertex.getY();
        }
        Structs.Mesh.Builder clone = Structs.Mesh.newBuilder();
        clone.addAllVertices(aMesh.getVerticesList());
        clone.addAllSegments(aMesh.getSegmentsList());

        for (Structs.Polygon polygon : aMesh.getPolygonsList()) {
            double[] point = {aMesh.getVerticesList().get(polygon.getCentroidIdx()).getX(), aMesh.getVerticesList().get(polygon.getCentroidIdx()).getY()};
            Structs.Polygon.Builder poly = Structs.Polygon.newBuilder(polygon);
            Structs.Property color;

            if (Math.sqrt(Math.pow(point[0] - maxX/2, 2) + Math.pow(point[1] - maxY/2, 2)) <= radius) {
                //set poly to land
                color = Structs.Property.newBuilder()
                        .setKey("biome")
                        .setValue(BIOMES.LAND.toString())
                        .build();
            } else {
                //set poly to ocean
                color = Structs.Property.newBuilder()
                        .setKey("biome")
                        .setValue(BIOMES.OCEAN.toString())
                        .build();
            }
            poly.addProperties(color);
            clone.addPolygons(poly);
        }
        island.setMesh(clone.build());
    }

    public void render(OvalIsland island) {
        //Makes a centred oval.
        final int radius = island.getRadius();
        Structs.Mesh aMesh = island.getMesh();
        //get max x value from mesh
        double maxX = 0;
        for (Structs.Vertex vertex : aMesh.getVerticesList()) {
            if (vertex.getX() > maxX) maxX = vertex.getX();
        }
        //get max y value from mesh
        double maxY = 0;
        for (Structs.Vertex vertex : aMesh.getVerticesList()) {
            if (vertex.getY() > maxY) maxY = vertex.getY();
        }

        Structs.Mesh.Builder clone = Structs.Mesh.newBuilder();
        clone.addAllVertices(aMesh.getVerticesList());
        clone.addAllSegments(aMesh.getSegmentsList());
        for (Structs.Polygon polygon : aMesh.getPolygonsList()) {
            double[] point = {aMesh.getVerticesList().get(polygon.getCentroidIdx()).getX(), aMesh.getVerticesList().get(polygon.getCentroidIdx()).getY()};
            Structs.Polygon.Builder poly = Structs.Polygon.newBuilder(polygon);
            Structs.Property color;
            double X = aMesh.getVerticesList().get(polygon.getCentroidIdx()).getX() - maxX / 2;
            double Y = aMesh.getVerticesList().get(polygon.getCentroidIdx()).getY() - maxY / 2;
            if (Math.pow(X, 2) + Math.pow(Y, 2) + (X * Y) <= Math.pow(radius, 2)) {
                //set poly to land
                color = Structs.Property.newBuilder()
                        .setKey("biome")
                        .setValue(BIOMES.LAND.toString())
                        .build();
            } else {
                //set poly to ocean
                color = Structs.Property.newBuilder()
                        .setKey("biome")
                        .setValue(BIOMES.OCEAN.toString())
                        .build();
            }
            poly.addProperties(color);
            clone.addPolygons(poly);
        }
        island.setMesh(clone.build());
    }

}
