package island.tools.Cities;

import Identifiers.STATUS;
import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import graphComponents.Node;
import island.tools.Adt.Vertex;

public class RealCity extends Vertex {
    private Identifiers.STATUS size;
    private Structs.Vertex v;
    public RealCity(STATUS size, Structs.Vertex v){
        super(v);
        this.size = size;
        this.v = v;
    }
    public STATUS getSize(){
        return size;
    }
    public Structs.Vertex getCorresponding(){
        return v;
    }
}
