package island.tools.checker;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;

import java.util.List;

public class GetVertex implements CheckSegmentKeys{

    public GetVertex(){}
    @Override
    public int findKey(Structs.Segment s, String id) {
        List<Structs.Property> properties = s.getPropertiesList();
        for (int i =0; i< properties.size(); i++){
            if (properties.get(i).getKey().equals(id)){
                return i;
            }
        }
        return -1;
    }
}
