package island.tools.Cities;


import Identifiers.STATUS;
import ca.mcmaster.cas.se2aa4.a2.io.Structs;

public class CapitalCity extends RealCity {
    public CapitalCity(Structs.Vertex vertex) {
        super(STATUS.CAPITAL, vertex);
    }
}
