package island.tools.enricher;


import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.Islands.Island;

public interface Enricher {

    void enrich(Island island);

}
