package island.tools.Islands;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.altimetricProfiles;
import island.tools.whittaker.DIAGRAMS;

public class CircleIsland extends Island {

    private final int radius;

    public CircleIsland(Structs.Mesh mesh, altimetricProfiles profile, int numberOfAquifers, int numberOfRivers, DIAGRAMS diagram, Long seed, int radius, int soil, int numLakes, int numCities) {
        super(mesh, profile, numberOfAquifers, numberOfRivers, diagram, seed, soil, numLakes, numCities);
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }
}
