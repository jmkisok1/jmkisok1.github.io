package island.tools.Adt;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;

public class Vertex {
    private final double x;
    private final double y;
    private Structs.Vertex myVertex;
    public Vertex(Structs.Vertex v){
        x = v.getX();
        y = v.getY();
        myVertex =v;
    }
    public Vertex(double x, double y){
        this.x = x;
        this.y = y;
    }
    public double[] getCoords(){
        return new double[]{this.x, this.y};
    }
    public Structs.Vertex getStructVertex(){
        return myVertex;
    }
}
