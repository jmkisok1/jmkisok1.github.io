package island.tools.Islands;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.altimetricProfiles;
import island.tools.whittaker.DIAGRAMS;

public class OvalIsland extends Island {
    public int radius;
    public OvalIsland(Structs.Mesh mesh, altimetricProfiles altimetricProfile, int numberOfAquifers, int numberOfRivers, DIAGRAMS diagram, Long seed, int radius, int soil, int numLakes, int numCities) {
        super(mesh, altimetricProfile, numberOfAquifers, numberOfRivers, diagram, seed, soil, numLakes, numCities);
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }
}
