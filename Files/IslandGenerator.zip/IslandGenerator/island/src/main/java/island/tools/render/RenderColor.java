package island.tools.render;

import Identifiers.STATUS;
import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.BIOMES;
import island.tools.Islands.Island;
import island.tools.checker.GetBiome;
import island.tools.checker.GetCity;
import island.tools.checker.GetVertex;


public class RenderColor implements Renderable {
    //Gives "colour" properties to polygons to colour them later

    public void render(Island island) {
        Structs.Mesh aMesh = island.getMesh();
        Structs.Mesh.Builder clone = Structs.Mesh.newBuilder();
        GetCity getCity = new GetCity();
        int location;
        GetBiome getBiome = new GetBiome();
        GetVertex getVertex = new GetVertex();
        for (Structs.Polygon poly: aMesh.getPolygonsList()) {

            poly = color(poly, BIOMES.valueOf(poly.getProperties(getBiome.findKey(poly)).getValue()));
            clone.addPolygons(poly);
        }
        for (Structs.Vertex cities: aMesh.getVerticesList()) {
            location = getCity.findKey(cities, "City");
            if (location != -1){
                 cities = colourCities(cities,location);
            }
            clone.addVertices(cities);
        }
        for (Structs.Segment s : aMesh.getSegmentsList()){
            location =getVertex.findKey(s, "Road");
            if (location != -1){
                s = colourRoads(s);
            }
            clone.addSegments(s);
        }
        island.setMesh(clone.build());
    }

    public Structs.Polygon color(Structs.Polygon poly, BIOMES biome) {
        String biome_color = switch (biome) {
            case OCEAN -> "0,94,255";
            case LAND -> "0,153,0";
            case LAKE -> "0,205,255";
            case BEACH -> "255,215,81";
            case TUNDRA -> "255,255,255";
            case TAIGA -> "176,255,182";
            case BOREAL_FOREST -> "0,51,0";
            case ALPINE_TUNDRA -> "203,255,254";
            case ALPINE_TAIGA -> "117,238,129";
            case ALPINE_FOREST -> "0,31,0";
            case DESERT -> "255,255,102";
            case SAVANNA -> "255,255,51";
            case GRASSLAND -> "51,255,51";
            case WOODLAND -> "0,204,0";
            case TROPICAL_FOREST -> "0,153,0";
            case TROPICAL_RAINFOREST -> "51,102,0";

            default -> "0,0,0"; // Add other biomes here
        };
        Structs.Property color = Structs.Property.newBuilder().setKey("rgb_color").setValue(biome_color).build();
        return Structs.Polygon.newBuilder(poly).addProperties(color).build();
    }
    private Structs.Vertex colourCities(Structs.Vertex v, int location){
        String city_Colour = switch(STATUS.valueOf(v.getProperties(location).getValue())){
            //More pink = smaller, more red = bigger.
            case CAPITAL -> "226,34,34";
            case TOWN -> "232,99,99";
            case VILLAGE -> "232,130,130";
            case HAMLET ->  "232,167,167";
            case COTTAGE -> "253,221,221";
            default -> "255,255,255";
        };
        Structs.Property color = Structs.Property.newBuilder().setKey("rgb_color").setValue(city_Colour).build();
        return Structs.Vertex.newBuilder(v).addProperties(color).build();
    }
    private Structs.Segment colourRoads(Structs.Segment s){
            Structs.Property color = Structs.Property.newBuilder().setKey("rgb_color").setValue("102,51,0").build();
            return Structs.Segment.newBuilder(s).addProperties(color).build();

    }

}
