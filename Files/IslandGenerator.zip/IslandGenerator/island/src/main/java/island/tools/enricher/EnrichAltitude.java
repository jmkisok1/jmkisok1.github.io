package island.tools.enricher;


import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.Islands.CircleIsland;
import island.tools.Islands.DonutIsland;
import island.tools.Islands.Island;
import island.tools.Islands.OvalIsland;
import island.tools.checker.GetBiome;
import island.tools.altimetricProfiles;
import island.tools.checker.GetElevation;

import java.util.ArrayList;
import java.util.Random;

public class EnrichAltitude implements Enricher {
    //Gives an island's polygons one of 3 kinds of altitude profiles.

    @Override
    public void enrich(Island island) {
        Structs.Mesh aMesh = island.getMesh();
        altimetricProfiles profile = island.getAltimetricProfile();

        aMesh = switch (profile) {
            case RANDOM -> randomEvevation(aMesh, island.getSeed());
            case ROLLING -> rollingElevation(aMesh, island.getSeed());
            case VOLCANO -> volcanoElevation(aMesh, island.getSeed());
            default -> aMesh;
        };
        island.setMesh(aMesh);
    }

    public Structs.Mesh randomEvevation(Structs.Mesh aMesh, Long seed) {
        Random randAlt = new Random();
        randAlt.setSeed(seed);
        Structs.Mesh.Builder copy = Structs.Mesh.newBuilder();
        copy.addAllSegments(aMesh.getSegmentsList());
        copy.addAllVertices(aMesh.getVerticesList());
        GetBiome getter = new GetBiome();
        int biomeLocation;
        //Land tiles get a random altitude 2-5 while water and beach tiles are preset.
        for (Structs.Polygon P:aMesh.getPolygonsList()) {
            biomeLocation = getter.findKey(P);
            switch (P.getProperties(biomeLocation).getValue()) {
                case "BEACH":
                    P = elevated(P, 0);
                case "LAKE":
                    P = elevated(P, 1);
                case "OCEAN":
                    P = elevated(P, 0);
                case "LAND":
                    P = elevated(P, randAlt.nextInt(2, 6));//Note that this picks from [2...5)
            }
            copy.addPolygons(P);
        }
        return copy.build();
    }

    public Structs.Mesh rollingElevation (Structs.Mesh aMesh, Long seed) {
        //Uses an average elevation to make alternating hills and flat lands
        Random randAlt = new Random();
        randAlt.setSeed(seed);
        Structs.Mesh.Builder copy = Structs.Mesh.newBuilder();
        copy.addAllSegments(aMesh.getSegmentsList());
        copy.addAllVertices(aMesh.getVerticesList());
        GetBiome getBiome = new GetBiome();
        GetElevation getElev = new GetElevation();
        int biomeLocation;
        int elevLocation;
        int avgNeighbourElevation = 0;
        for (Structs.Polygon P: aMesh.getPolygonsList()) {
            biomeLocation = getBiome.findKey(P);
            switch (P.getProperties(biomeLocation).getValue()) {
                case "BEACH", "OCEAN":
                    P = elevated(P, 0);
                case "LAND":
                    int elevation;
                    ArrayList<Integer> neighbourElevation = new ArrayList<>();
                    for (int neigbourIdx: P.getNeighborIdxsList()) {
                        try {
                            elevLocation = getElev.findKey(aMesh.getPolygonsList().get(neigbourIdx));
                            neighbourElevation.add(Integer.parseInt(aMesh.getPolygonsList().get(neigbourIdx).getProperties(elevLocation).getValue()));
                            avgNeighbourElevation = neighbourElevation.stream().mapToInt(Integer::intValue).sum() / neighbourElevation.size();
                        } catch (IllegalArgumentException ignored) {}
                    }
                    elevation = randAlt.nextInt(avgNeighbourElevation - 1, avgNeighbourElevation + 2);
                    if (elevation < 0) {
                        elevation = 0;
                    }
                    if (elevation > 5) {
                        elevation = 5;
                    }
                    P = elevated(P, elevation);
            }
            copy.addPolygons(P);
        }
        return copy.build();
    }

    private Structs.Polygon elevated(Structs.Polygon template, int height){
        //Method for quickly changing elevation property to save time
        Structs.Property elevation = Structs.Property.newBuilder().setKey("elevation").setValue(String.valueOf(height)).build();
        Structs.Polygon.Builder newPoly = Structs.Polygon.newBuilder(template);
        newPoly.addProperties(elevation);
        template = newPoly.build();
        return template;
    }

    public Structs.Mesh volcanoElevation (Structs.Mesh aMesh, Long seed) {
        //Makes a profile that is tallest in the middle then flattens out
        Random randAlt = new Random();
        randAlt.setSeed(seed);
        Structs.Mesh.Builder copy = Structs.Mesh.newBuilder();
        copy.addAllSegments(aMesh.getSegmentsList());
        copy.addAllVertices(aMesh.getVerticesList());
        GetBiome getBiome = new GetBiome();
        int biomeLocation;

        double maxX = 0;
        for (Structs.Vertex vertex : aMesh.getVerticesList()) {
            if (vertex.getX() > maxX) maxX = vertex.getX();
        }
        //get max y value from mesh
        double maxY = 0;
        for (Structs.Vertex vertex : aMesh.getVerticesList()) {
            if (vertex.getY() > maxY) maxY = vertex.getY();
        }

        int inner_radius = 100;
        int inner_middle_radius = 200;
        int outer_middle_radius = 300;
        int outer_radius = 400;

        for (Structs.Polygon P : aMesh.getPolygonsList()) {
            biomeLocation = getBiome.findKey(P);
            switch (P.getProperties(biomeLocation).getValue()) {
                case "BEACH", "OCEAN":
                    P = elevated(P, 0);
                case "LAND":
                    double[] point = {aMesh.getVerticesList().get(P.getCentroidIdx()).getX(), aMesh.getVerticesList().get(P.getCentroidIdx()).getY()};
                    if (Math.sqrt(Math.pow(point[0] - maxX / 2, 2) + Math.pow(point[1] - maxY / 2, 2)) <= outer_radius &&
                            Math.sqrt(Math.pow(point[0] - maxX / 2, 2) + Math.pow(point[1] - maxY / 2, 2)) >= outer_middle_radius) {
                        int elevation = randAlt.nextInt(1,3);
                        P = elevated(P,elevation);
                    }
                    else if (Math.sqrt(Math.pow(point[0] - maxX / 2, 2) + Math.pow(point[1] - maxY / 2, 2)) <= outer_middle_radius &&
                            Math.sqrt(Math.pow(point[0] - maxX / 2, 2) + Math.pow(point[1] - maxY / 2, 2)) >= inner_middle_radius) {
                        int elevation = randAlt.nextInt(2,4);
                        P = elevated(P,elevation);
                    }
                    else if (Math.sqrt(Math.pow(point[0] - maxX / 2, 2) + Math.pow(point[1] - maxY / 2, 2)) <= inner_middle_radius &&
                            Math.sqrt(Math.pow(point[0] - maxX / 2, 2) + Math.pow(point[1] - maxY / 2, 2)) >= inner_radius) {
                        int elevation = randAlt.nextInt(3, 5);
                        P = elevated(P, elevation);
                    }
                    else if (Math.sqrt(Math.pow(point[0] - maxX / 2, 2) + Math.pow(point[1] - maxY / 2, 2)) <= inner_middle_radius) {
                        int elevation = randAlt.nextInt(4, 6);
                        P = elevated(P, elevation);
                    }
                    else {
                        P = elevated(P,1);
                    }
            }
            copy.addPolygons(P);
        }
        return(copy.build());
    }
}

