package island.tools.Cities;

import Identifiers.STATUS;
import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import graphComponents.*;
import island.tools.Adt.*;


import java.util.*;

public class MakeCities implements CityMaker{
    //Meshes store a capital and a list of cities. Here is where those cities are made
    private Random randy;
    private List<RealCity> cities;
    private List<Structs.Vertex> usedVertices;
    public MakeCities(){
        randy = new Random();
        cities = new ArrayList<>();
    }

    @Override
    public void placeRandomCities(int numCities, Structs.Mesh aMesh, Mesh myMesh) {
        //Pick a random vertex to be the capital
        usedVertices = new ArrayList<>();
        int capitalLocation = randy.nextInt(aMesh.getVerticesCount());
        int randomLocation, randomSize;
        CapitalCity capital = new CapitalCity(aMesh.getVertices(capitalLocation));
        cities.add(capital);
        //Keep track of what vertices will be cities
        usedVertices.add(aMesh.getVertices(capitalLocation));
        for (int i = 0; i < numCities; i++){ //Later change 1 < 10 to i < numCities
            //Pick a random vertex, if it's already a city, continue
            randomLocation = randy.nextInt(aMesh.getVerticesCount());
            if (usedVertices.contains(aMesh.getVertices(randomLocation))){
                i--;
                continue;
            }
            //Pick a city size from 2 (cottage) to 5 (capital)
            randomSize = randy.nextInt(2,6);
            RealCity newCity = new RealCity(STATUS.values()[randomSize],aMesh.getVertices(randomLocation));
            usedVertices.add(aMesh.getVertices(randomLocation));
            cities.add(newCity);
        }
        placeNullCities(aMesh);
        for(RealCity city: cities){
            myMesh.add(city);
        }
    }

    private void placeNullCities(Structs.Mesh aMesh){
        for (Structs.Vertex v: aMesh.getVerticesList()) {
            if (!usedVertices.contains(v)){
                //Every vertex not associated with a city is declared as NoCity
                cities.add(new NoCity(v));
            }
        }
    }
}
