package island.tools;

public enum altimetricProfiles {
    ROLLING, VOLCANO, RANDOM
}
