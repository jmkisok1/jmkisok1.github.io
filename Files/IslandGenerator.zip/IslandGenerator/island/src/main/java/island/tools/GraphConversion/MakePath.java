package island.tools.GraphConversion;

import GraphOperations.ShortestPath;
import GraphOperations.ShortestPathBellmanFord;
import Identifiers.STATUS;
import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import graphComponents.Graph;
import graphComponents.Node;
import island.tools.Adt.*;
import island.tools.Cities.RealCity;

import java.util.ArrayList;
import java.util.List;

public class MakePath implements PathMaker{
    //Enriches vertices and segments in the Structs.Mesh for visualization of the shortest path algorithm
    @Override
    //Driver code
    public Structs.Mesh makePaths(Mesh myMesh,Structs.Mesh yoMesh){
        List<List<Node>> paths = new ArrayList<>(); //Stores all shortest paths from cities to capital
        RealCity currentCity;
        List<Structs.Vertex> newVertices = new ArrayList<>();
        newVertices.addAll(yoMesh.getVerticesList());
        ShortestPathBellmanFord ford = new ShortestPathBellmanFord();
        for (int i = 0; i<myMesh.getCitiesSize(); i++){ //Converts all cities to nodes and runs the shortest path to capital
            currentCity = myMesh.getCity().get(i);
            newVertices.add(makeCityVertex(currentCity));
            paths.add(makePath(myMesh.getGraph(),ford,i));
        }
        //Makes an enriched Structs.Mesh that identifies its cities and shortest-path roads
        return Structs.Mesh.newBuilder()
                .addAllPolygons(yoMesh.getPolygonsList())
                .addAllVertices(newVertices)
                .addAllSegments(identifyPaths(paths,yoMesh)).build();
    }

    private List<Node> makePath(Graph g, ShortestPath shortestPath, int time) {
        List<Node> path;
        g.setEdges();
        path = shortestPath.findPath(g,g.get(time),g.get(0));
        return path;
    }
    private Structs.Vertex makeCityVertex(RealCity city){
        //Makes an enriched vertex identifying there is a city.
        Structs.Property type = Structs.Property.newBuilder()
                .setKey("City")
                .setValue(city.getSize().toString()).build();
        return Structs.Vertex.newBuilder()
                .setX(city.getCoords()[0])
                .setY(city.getCoords()[1])
                .addProperties(type).build();
    }
    private int findVertex(Node n, List<Structs.Vertex> vertices){
        //Finds the corresponding Structs.Vertex with the same coordinates as the given node
        for(Structs.Vertex v: vertices){
            if (Double.valueOf(v.getX()).equals(n.getCoords()[0]) && Double.valueOf(v.getY()).equals(n.getCoords()[1])){
                return vertices.indexOf(v);
            }
        }
        throw new RuntimeException("Couldn't find the vertex");
    }
    private List<Structs.Segment> identifyPaths(List<List<Node>> BFord, Structs.Mesh aMesh){
        //Goes through the shortest paths and makes new segments out of the edges with road identifiers
        int v1Idx, v2Idx;
        List<Structs.Segment> segments = new ArrayList<>();
        segments.addAll(aMesh.getSegmentsList());
        for(List<Node> path: BFord){
            for (int i = 0; i < path.size() -1; i++){
                v1Idx = findVertex(path.get(i),aMesh.getVerticesList());
                v2Idx = findVertex(path.get(i+1),aMesh.getVerticesList());
                Structs.Property type = Structs.Property.newBuilder()
                        .setKey("Road")
                        .setValue("True").build();
                Structs.Segment s = Structs.Segment.newBuilder()
                        .setV1Idx(v1Idx)
                        .setV2Idx(v2Idx)
                        .addProperties(type).build();
                segments.add(s);
            }
        }
        return segments;
    }
}
