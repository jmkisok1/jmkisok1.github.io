package island.tools.Islands;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.altimetricProfiles;
import island.tools.whittaker.Arctic;
import island.tools.whittaker.DIAGRAMS;
import island.tools.whittaker.Diagram;

public abstract class Island {
    //Abstract class representing an island containing useful properties such as its mesh, number of lakes, etc.
    private Structs.Mesh mesh;
    private final altimetricProfiles altimetricProfile;
    private final int numberOfAquifers;
    private final int numberOfRivers;
    private final DIAGRAMS diagram;
    private final Long seed;
    private final int soilLevel;
    private final int numLakes;
    private final int numCities;

    public Island(Structs.Mesh mesh, altimetricProfiles altimetricProfile, int numberOfAquifers, int numberOfRivers, DIAGRAMS diagram, Long seed, int soilLevel, int numLakes, int numCities) {
        this.altimetricProfile = altimetricProfile;
        this.mesh = mesh;
        this.numberOfAquifers = numberOfAquifers;
        this.numberOfRivers = numberOfRivers;
        this.diagram = diagram;
        this.seed = seed;
        this.soilLevel = soilLevel;
        this.numLakes = numLakes;
        this.numCities = numCities;
    }

    //Getters
    public Structs.Mesh getMesh() {
        return mesh;
    }
    public altimetricProfiles getAltimetricProfile() {
        return altimetricProfile;
    }
    public void setMesh(Structs.Mesh mesh) {
        this.mesh = mesh;
    }
    public int getNumberOfAquifers() {
        return numberOfAquifers;
    }
    public int getNumberOfRivers() {return numberOfRivers;}
    public DIAGRAMS getDiagram() {return diagram;}
    public Long getSeed() {return seed;}
    public int getSoilLevel (){return soilLevel;}
    public int getNumLakes(){return numLakes;}
    public int getNumCities(){return numCities;}
}
