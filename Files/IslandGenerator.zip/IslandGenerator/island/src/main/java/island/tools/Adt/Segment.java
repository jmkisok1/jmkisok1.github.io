package island.tools.Adt;

import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import island.tools.checker.*;

public class Segment {
    private final Vertex start;
    private final Vertex end;
    private GetVertex getVertex;
    public Segment(Structs.Vertex v1, Structs.Vertex v2){
        start = new Vertex(v1);
        end = new Vertex(v2);
    }
    private double[] extractCoords(Structs.Segment s){
        double[] coords = new double[4];
        getVertex = new GetVertex();
            coords[0] = Double.parseDouble(s.getProperties(getVertex.findKey(s,"v1x")).getValue());
            coords[1] = Double.parseDouble(s.getProperties(getVertex.findKey(s,"v1y")).getValue());
            coords[2] = Double.parseDouble(s.getProperties(getVertex.findKey(s,"v2x")).getValue());
            coords[3] = Double.parseDouble(s.getProperties(getVertex.findKey(s,"v2y")).getValue());
        return coords;
    }
    public Vertex getStart(){
        return start;
    }
    public Vertex getEnd(){
        return end;
    }
}
