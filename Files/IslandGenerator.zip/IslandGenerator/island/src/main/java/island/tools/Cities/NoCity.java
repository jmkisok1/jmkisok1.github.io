package island.tools.Cities;

import Identifiers.STATUS;
import ca.mcmaster.cas.se2aa4.a2.io.Structs;

public class NoCity extends RealCity{

    public NoCity(Structs.Vertex v) {
        super(STATUS.NO_CITY, v);
    }
}
