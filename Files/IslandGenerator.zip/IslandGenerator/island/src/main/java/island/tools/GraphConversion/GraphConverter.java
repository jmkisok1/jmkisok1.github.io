package island.tools.GraphConversion;

import Identifiers.STATUS;
import Identifiers.WEIGHTS;
import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import graphComponents.*;
import island.tools.Adt.*;
import island.tools.Cities.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GraphConverter implements Converter {
    //Takes the vertices and segments in the mesh and makes them nodes and edges for a graph.

    List<Node> nodes;
    List<Structs.Vertex> correspondingVertices;
    public void convert(Mesh myMesh){
        cityToNode(myMesh);
        segmentToEdge(myMesh.getGraph(), myMesh);
    }
    @Override
    //Takes all cities and makes them nodes
    public void cityToNode(Mesh myMesh) {
        correspondingVertices = new ArrayList<>();
        Graph g = new Graph();
        //Node 0 is capital.
        Node capitalNode = new Node(myMesh.getCapital().getCoords()[0],myMesh.getCapital().getCoords()[1],0);
        g.addNode(capitalNode);
        correspondingVertices.add(myMesh.getCapital().getCorresponding());
        Node newNode;
        int i = 1;
        //Nodes 1...[cities.size] are cities. All nodes numbered after are blank (no city)
        for (RealCity myCity : myMesh.getCity()){
            newNode = new Node(myCity.getCoords()[0],myCity.getCoords()[1], i);
            g.addNode(newNode);
            correspondingVertices.add(myCity.getCorresponding());
            i++;
        }
        int j = i +1;
        for (NoCity land : myMesh.getLand()){
            newNode = new Node(land.getCoords()[0],land.getCoords()[1], j);
            g.addNode(newNode);
            correspondingVertices.add(land.getCorresponding());
            j++;
        }
        myMesh.setGraph(g);
    }

    @Override
    public void segmentToEdge(Graph g, Mesh myMesh) {
        //Makes all segments in the mesh as edges in the graph. Then we can run shortest path.
        nodes = g.getNodes();
        Node start, end;
        Edge e;
        Structs.Vertex v1,v2;
        for(Segment s : myMesh.getSegments()){
            v1 = s.getStart().getStructVertex();
            v2 = s.getEnd().getStructVertex();
            start = findCorresponding(v1);
            end = findCorresponding(v2);
            //All edges have weight one
            e = new Edge(start, end, WEIGHTS.ONE);
            g.addEdge(e);
        }
        myMesh.setGraph(g);


    }
    private Node findCorresponding(Structs.Vertex v){
        //Finds the node at the same x,y as the given vertex
        //Nodes are sorted from 0 upwards, so the correspondingVertices list contains what we need.
        int location = correspondingVertices.indexOf(v);
        try{
        return nodes.get(location);
        }
        catch(Exception e) {
            throw new RuntimeException("Couldn't find corresponding node");
        }
    }
}
