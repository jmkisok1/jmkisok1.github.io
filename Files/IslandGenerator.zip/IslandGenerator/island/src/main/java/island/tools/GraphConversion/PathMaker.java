package island.tools.GraphConversion;
import GraphOperations.ShortestPath;
import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import graphComponents.*;
import island.tools.Adt.Mesh;

import java.util.*;

public interface PathMaker {
    Structs.Mesh makePaths(Mesh myMesh, Structs.Mesh yoMesh);
}
