package island.tools;
import org.apache.commons.cli.*;

import java.util.HashMap;
import java.util.Map;

public class Config {
    //Class for getting input arguments
    private static final String INPUT = "i";
    private static final String OUTPUT = "o";
    private static final String MODE = "mode";
    private static final String SHAPE = "shape";
    private static final String ALTITUDE = "altitude";
    private static final String AQUIFER = "aquifer";
    private static final String BIOMES = "biomes";
    private static final String SEED = "seed";
    private static final String SOIL = "soil";
    private static final String LAKES= "lakes";
    private static final String CITIES = "cities";

    private final CommandLine cli;

    private CommandLineParser parser() {
        return new DefaultParser();
    }

    public Config(String[] args) {
        try {
            this.cli = parser().parse(options(), args);
        } catch (ParseException e) {
            throw new IllegalArgumentException(e);
        }
    }

    public Map<String, String> export() {
        Map<String, String> result = new HashMap<>();
        for(Option o: cli.getOptions()){
            result.put(o.getOpt(), o.getValue(""));
        }
        return result;
    }

    public String export(String key) {
        if (!cli.hasOption(key)) return "No value";
        return cli.getOptionValue(key);
    }

    private Options options() {
        Options options = new Options();
        options.addOption(new Option(INPUT, true, "Input file name"));
        options.addOption(new Option(OUTPUT, true, "Output file name"));
        options.addOption(new Option(MODE, true, "Mode"));
        options.addOption(new Option(SHAPE, true, "Shape"));
        options.addOption(new Option(ALTITUDE, true, "Altitude"));
        options.addOption(new Option(AQUIFER, true, "Aquifer"));
        options.addOption(new Option(BIOMES, true, "Biomes"));
        options.addOption(new Option(SEED, true, "Seed"));
        options.addOption(new Option(SOIL, true, "Soil"));
        options.addOption(new Option(LAKES, true, "Lakes"));
        options.addOption(new Option(CITIES, true, "Cities"));
        return options;
    }
}
