package island.tools.GraphConversion;

import graphComponents.Graph;
import island.tools.Adt.*;
import island.tools.Cities.RealCity;

import java.util.List;

public interface Converter {
    void cityToNode(Mesh myMesh);
    void segmentToEdge(Graph g, Mesh myMesh);
}
