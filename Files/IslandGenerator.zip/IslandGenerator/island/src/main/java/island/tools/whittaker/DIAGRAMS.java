package island.tools.whittaker;

public enum DIAGRAMS {
    TROPICAL, ARCTIC
        }
