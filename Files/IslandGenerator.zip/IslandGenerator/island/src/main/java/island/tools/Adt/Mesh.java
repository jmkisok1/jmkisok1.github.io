package island.tools.Adt;

import Identifiers.STATUS;
import ca.mcmaster.cas.se2aa4.a2.io.Structs;
import graphComponents.Graph;
import island.tools.Cities.*;

import java.util.*;

public class Mesh{
    private List<Vertex> vertices;
    private Graph correspondingGraph;
    private Set<Segment> segments;
    private List<RealCity> cities;
    private List<NoCity> land;
    private CapitalCity capital;
    public Mesh(){
        cities = new ArrayList<>();
        land = new ArrayList<>();
        correspondingGraph = new Graph();
    }
    public void setSegments(Set<Segment> segments){
        this.segments = segments;
    }
    public void setVertices(List<Vertex> vertices){
        this.vertices = vertices;
    }
    public void add(RealCity city){
        //This is technical debt. Originally, I had 3 overloaded methods that took in a Real, No, or Capital city.
        //But Java always does the method for RealCity because it's a superclass and it was too late to rework the code a lot.
        if (city.getSize().equals(STATUS.CAPITAL)) {
            this.capital = (CapitalCity) city;
        }
        else if (city.getSize().equals(STATUS.NO_CITY)){
            land.add((NoCity) city);
        }
        else {
            cities.add(city);
        }
    }
    public void setGraph(Graph g){
        correspondingGraph = g;
    }
    public Graph getGraph(){
        return correspondingGraph;
    }
    public int getCitiesSize(){
        return cities.size();
    }
    public List<RealCity> getCity(){
        return cities;
    }
    public List<NoCity> getLand(){
        return land;
    }
    public CapitalCity getCapital(){
        return capital;
    }
    public Set<Segment> getSegments(){
        return segments;
    }

}
