package ca.mcmaster.cas.se2aa4.a2.generator.adt;

public interface Cropable<T> {

    T crop(float maxX, float maxY);

}
