package ca.mcmaster.cas.se2aa4.a2.generator.specification;

import ca.mcmaster.cas.se2aa4.a2.generator.adt.Mesh;

public interface Buildable {

    Mesh build();

}
