# Mesh Generator

  - Author: Jacob Kish

## How to install?

```
mvn install
```

It creates two jars:

  1. `generator/generator.jar` to generate meshes
  2. `visualizer/visualizer.jar` to visualize such meshes as SVG files

## Examples of execution

### Generating a mesh, grid or irregular

```
java -jar generator/generator.jar -k grid -h 1080 -w 1920 -p 1000 -s 20 -o img/grid.mesh
java -jar generator/generator.jar -k irregular -h 1080 -w 1920 -p 1000 -s 20 -o img/irregular.mesh
```

One can run the generator with `-help` as option to see the different command line arguments that are available

### Visualizing a mesh, (regular or debug mode)

```
java -jar visualizer/visualizer.jar -i img/grid.mesh -o img/grid.svg          
java -jar visualizer/visualizer.jar -i img/grid.mesh -o img/grid_debug.svg -x
java -jar visualizer/visualizer.jar -i img/irregular.mesh -o img/irregular.svg   
java -jar visualizer/visualizer.jar -i img/irregular.mesh -o img/irregular_debug.svg -x
```

Note: PDF versions of the SVG files were created with `rsvg-convert`.

### Enrich the mesh as a Island: 2 ways
```
java -jar island/island.jar -i input.mesh -o output.mesh -mode ...
java -jar island/island.jar -i input.mesh -o output.mesh -shape -altitude -soil ...
```
### Add flags:
- i: input (required)
- o: output (required)

- mode: lagoon, volcano, greenland
  Modes are presets with a set elevation (random, volcano, rolling), climate(tropical, tropical, arctic) and number of lakes (0,5,5).
  Using other flags with a mode will have no effect.

- seed: generated when an island is made (optional)
  When making a mesh, adding the -seed flag will make an exact copy for the _same shape_. 
  Use as: -i -o -shape -seed for best results.
- shape: oval, circle, donut
  Circle by default. Circle islands will always have rolling altitude no matter the input for altitude.
- lakes:number of lakes
  0 if not specified/default
- altitude: rolling, random, volcano
  Random by default.
- aquifer: number of aquifers
  Set to 0 by default
- soil: water absorption level (1-3)
  Set to 1 by default
- biomes: arctic or tropical type islands
  Arctic by default.
- cities: number of cities
  Set to 10 by default. I recommend 10 or less because wow does this thing take a long time.