# Logbook
## Sat, Jan 14, 2023
Made the logbook (obviously) and the PDF report.

## Sun, Jan 15, 2023
Worked on basic rolling and getting points from diamonds/gold.

## Mon, Jan 16, 2023
Tried to implement re-rolling a random # of dice.

## Tues, Jan 17, 2023
Implemented re-rolling, and deciding if a player loses a turn
(3 skulls) or get points.

## Wed, Jan 18, 2023
Made 2 players and tried to get them to play a full game.
Program became softlocked.

## Thurs, Jan 19, 2023
Found out why it was softlocked!!! Now 2 players can
play. They play 42 games and then we get a percentage.
Added log42j but I have no idea how it works. I wish
Prof Mosser had given us more documentation or
help finding some.

## Sat, Jan 21, 2023
Put in the log4j2 logger and reduced technical debt 
throughout, especially in the reroll() method. Also
made the program count draws as well as wins.

## Sun, Jan 22, 2023
Implemented log tracing by command-line argument 0.
Added some more setters and getters to privatize
object variables.

## Mon, Jan 23, 2023
F12 - players get points for 3 or more of a kind in 
their rolls.

## Tues, Jan 24, 2023
F13 - Strategy for maximizing combos implemented

## Wed, Jan 25, 2023
F14-F16 - Sea Battle
## Thurs, Jan 26, 2023
Logging and command line arguments for Sea Battle and strategies
## Fri, Jan 27, 2023
Implemented monkey business
## Sat, Jan 28, 2023
Big overhaul and reduction of technical debt. Added comments
## Sun, Jan 29, 2023
Updated logbook for the past 2 days because I forgot