# A1 - Piraten Karpen

  * Author: Jacob Kish
  * Email: kishj1@mcmaster.ca

## Build and Execution

  * To clean your working directory:
    * `mvn clean`
  * To compile the project:
    * `mvn compile`
  * To run the project in development mode:
    * `mvn -q exec:java` (here, `-q` tells maven to be _quiet_)
  * To package the project as a turn-key artefact:
    * `mvn package`
  * To run the packaged delivery:
    * `java -jar target/piraten-karpen-jar-with-dependencies.jar` 
  * Full syntax for running: 
    * mvn exec:java -Dexec.args="[Logging] [Player1Strategy] [Player2Strategy]"
    * By default, or in case of not 3 arguments, the program runs with combo strategy and logging off.
    * To activate logging, use argument Trace. To give a player random strategy, use argument Random (case sensitive).
  * Example 1: logging on, player 1 with random strategy and player 2 with combo strategy:
    * mvn exec:java -Dexec.args="Trace Random Combo"
  * Example 2: logging off, both players with combo strategy:
    * mvn exec:java -Dexec.args="off default default"
  * Example 3: logging on, two random strategies:
    * `java -jar target/piraten-karpen-jar-with-dependencies.jar Trace Random Random`


Remark: **We are assuming here you are using a _real_ shell (e.g., anything but PowerShell on Windows)**

## Feature Backlog

 * Status: 
   * Pending (P), Started (S), Blocked (B), Done (D)
 * Definition of Done (DoD):
   *  A feature that faithfully and logically implements its backlog description without clearly jeopardizing other features
   * A user should agree the program functions as described and not get confused at the backlog's implementation

### Backlog 

| MVP? | Id  | Feature  | Status  |  Started  | Delivered |
| :-:  |:-:  |---       | :-:     | :-:       | :-:       |
| x   | F01 | Roll eight dice |  D | 01/14/23 | 01/15/23  |
| x   | F02 | Diamonds and gold score points  | D | 01/15/23 | 01/15/23  |
| x   | F03 | Players re-roll 2 or more dice - one time | D |  01/16/23  |  01/17/23 |
| x   | F04 | Turn ends with 3 skulls | D | 01/16/23 | 01/17/23 |
| x   | F06 | Skulls cannot be rerolled | D | 01/17/23 |  01/17/23  |
| x   | F07 | Player keeps rerolling unless they pick to reroll 0 |  D | 01/17/23 | 01/17/23  |
| x   | F08 | Player also keeps rerolling unless 3 skulls | D | 01/17/23 |  01/17/23  |
| x   | F09 | Add second player/turns | D | 01/18/23 |  01/18/23  |
| x   | F10 | 6000 points victory | D |  01/18/23  |  01/19/23  | 
| x   | F11 | Get win percentage | D | 01/18/23  | 01/18/23
| x   | F12 | Score points for 3+ multiples | D | 01/23/23 | 01/23/23 |
| x   | F13 | Implement strategy to maximize multiples | D | 01/23/23 |  01/24/23  |
| x   | F14 | Implement card deck with "nop" and "sea battle" | D | 01/25/23 |  01/25/23  |
| x   | F15 | Sea battle - win only gives points on card | D | 01/25/23 |  01/25/23  |
| x   | F16 | Sea battle - player can reroll after getting n sabres | D | 01/25/23 | 01/25/23   |
| x   | F17 | Add logging for sea battle | D | 01/25/23 |  01/26/23  |
| x   | F18 | Command line arguments to determine strategy | D | 01/26/23 |  01/26/23  |
| x   | F19 | Add monkey business card | D | 01/27/23 |  01/27/23  |
| x   | F20 | Make parrot = monkey when MB card appears | D | 01/27/23 |  01/27/23  |
