import pk.PlayTheGame;

public class PiratenKarpen {

    public static void main(String[] args) {
        try {
            PlayTheGame.runGame(args[0], args[1], args[2]);
        }
        catch(Exception e){
            PlayTheGame.runGame("Trace", "Combo", "Combo");
        }
    }
    
}
