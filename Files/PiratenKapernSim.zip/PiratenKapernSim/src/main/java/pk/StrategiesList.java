package pk;

public enum StrategiesList{
    RANDOM, COMBO_FOCUS
}
