package pk;

import java.util.ArrayList;
import java.util.Random;

import static pk.PlayTheGame.drawDeck;
import static pk.PlayTheGame.logger;

public class Player{
    //Class representing a player. The player has hands of dice, total points, wins, a name, and a strategy.
    private int myPoints;
    private int wins;
    private Dice myRoll;
    private ArrayList<Faces> mySkulls;
    private ArrayList<Faces> myHeld;
    private final boolean trace; //If true, the log file keeps track of the game.
    private final String name;
    private final StrategiesList myStrategy;
    private CardFaces myCard;

    public Player(String logChoice, String name, String strategyChoice){
        this.name = name;
        myPoints = 0;
        wins = 0;
        if (logChoice.equals("Trace")) trace = true;
        else trace = false;
        if (strategyChoice.equals("Random")) myStrategy = StrategiesList.RANDOM;
        else myStrategy = StrategiesList.COMBO_FOCUS;
        myHeld = new ArrayList<>();
        mySkulls = new ArrayList<>();
    }
    //This method just makes the player play a turn with whatever strategy they were assigned.
    public void fullPlay(){
        myCard = drawDeck.pickRandom();
        myRoll = new Dice(myCard);
        if (trace) logger.debug(name+ " has drawn a "+myCard+" card");
        if (myCard.equals(CardFaces.SEABATTLE2)) battleStrategy(2);
        else if (myCard.equals(CardFaces.SEABATTLE3)) battleStrategy(3);
        else if (myCard.equals(CardFaces.SEABATTLE4)) battleStrategy(4);
        else if (myStrategy.equals(StrategiesList.RANDOM)) randomStrategy();
        else comboStrategy();
    }

    //***Strategy Methods***

    //Random re-rolling strategy. The player will roll once then re-roll until 3+ skulls accumulate, or they
    //choose to swap out 0 dice. Points are only scored if the while breaks from swapping 0.
    private void randomStrategy(){
        int swap =1; //Number of dice to re-roll. Random.
        mySkulls.clear(); //New turn, clear the old skull hand.
        myRoll.roll(8); //An initial roll to get started.

        while(swap!=0) { //Player will re-roll until they get 3 skulls or swap variable = 0

            //Move all the skulls rolled into a separate arraylist. This simplifies re-rolling.
            myRoll.moveDice(mySkulls, Faces.SKULL);

            //Stop re-rolling if more than 2 skulls show up.
            if (mySkulls.size()>=3) break;
            while(true) {
                swap = (int) (Math.random() * myRoll.size());
                if (swap > 2 || swap == 0) break; //Get a different random # if 1 or 2 dice are to be swapped.
            }
            myRoll.reroll(swap);
        }
        //Re-rolling is done. Only give points if the player has <3 skulls.
        if (mySkulls.size()<3) {
            myPoints+= myRoll.getPoints();
            if (trace) logger.debug( name+" scores "+myRoll.getPoints()); //Display each player's score after each turn
        }
        if(mySkulls.size()>=3 && trace){
            logger.debug(name+" has rolled 3 skulls and lost their turn");
        }
    }

    //Combo strategy. The player rolls, finds the most common face, and re-rolls several times. The player may choose to
    //hold different dice, eg if they are holding 2 parrots then they roll 2 gold (and no parrots) they will hold the gold instead.
    private void comboStrategy(){
        Random rand = new Random();
        mySkulls.clear();
        myHeld.clear();
        myRoll.roll(8);
        int counter = 0;
        Faces mode; //Represents the most common face in the hand. Re-rolls will try to get more of this.
        int retries = rand.nextInt(3,6); //Unless they get 3 skulls, players will try 3-5 re-rolls to maximize their combo.
        myRoll.moveDice(mySkulls, Faces.SKULL);
        while(counter < retries){
            if(mySkulls.size()>=3) break;
            mode = myRoll.findMode(myHeld);
            //If dice are being held, move any matching dice from the last roll to the "held" hand.
            if (myHeld.size()>0 && myRoll.contains(myHeld.get(0))){
                myRoll.moveDice(myHeld,myHeld.get(0));
            }
            //If, when re-rolling, a different face shows up more than the previous held face, switch out the dice being
            //held. Eg, holding 2 parrots and roll 3 gold, hold gold next time around.
            if (myRoll.frequency(mode)>myHeld.size() || myRoll.frequency(mode) == myHeld.size() && (mode.equals(Faces.DIAMOND) || mode.equals(Faces.GOLD))) {
                counter = 0;
                myRoll.addAll(myHeld);
                myHeld.clear();
                myRoll.moveDice(myHeld, mode);
            }
            if (myHeld.size() + mySkulls.size()>=8) break; //Eg: 6 parrots and 2 skulls. No point re-rolling.
            myRoll.reroll(myRoll.size());
            if (myRoll.contains(Faces.SKULL)) myRoll.moveDice(mySkulls, Faces.SKULL);
            counter++;
        }

        if (mySkulls.size()<3) {
            myRoll.addAll(myHeld);
            myPoints += myRoll.getPoints();
            if (trace) logger.debug(name+ " scores "+myRoll.getPoints()+" points");
        }
        else {
            if (trace) logger.debug(name+ " has rolled 3 skulls and lost their turn");
        }
    }

    //Sea battle strategy. The player first tries to get the required amount of sabres, then will push their luck
    //a few more times to get even more points.
    private void battleStrategy(int sabresRequired){
        Random rand = new Random();
        mySkulls.clear();
        myHeld.clear();
        myRoll.roll(8);
        if(myRoll.contains(Faces.SKULL)) myRoll.moveDice(mySkulls,Faces.SKULL);
        //First, the player will roll to try to get n sabres.
        while(mySkulls.size()<3){
            myRoll.moveDice(myHeld,Faces.SABER);
            if (myHeld.size()>= sabresRequired) break;
            else myRoll.reroll(myRoll.size());
            myRoll.moveDice(mySkulls,Faces.SKULL);
        }
        //If they get the required sabres, they will push their luck 1-2 times to score even more points.

        for (int i = 0; i< rand.nextInt(1,3);i++) {
            myRoll.reroll(myRoll.size());
            myRoll.moveDice(mySkulls, Faces.SKULL);
            if (mySkulls.size() >= 3) {
                myPoints -= myRoll.seaBattlePoints(myCard);
                if (trace) logger.debug(name+ " has lost the sea battle and "+myRoll.seaBattlePoints(myCard)+" points");
                return;
            }
            myRoll.moveDice(myHeld, Faces.SABER);
        }
        myRoll.addAll(myHeld);
        myPoints+=myRoll.getPoints();
        if(trace) logger.debug(name+ " has won the sea battle and "+myRoll.getPoints()+" total points");

    }

    //***Setters and getters***

    public void clearPoints(){
        myPoints = 0;
    }

    public int getPoints(){
        return myPoints;
    }
    public int getWins(){
        return wins;
    }
    public void giveWin(){
        wins++;
    }
    public boolean winCondition(){
        return myPoints >= 6000;
    }

}
