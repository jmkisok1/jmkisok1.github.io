package pk;
import java.util.*;


public class Dice{
    //Class for handling hands of dice, i.e. ArrayLists of Face objects. Has a random object for picking
    //random dice to remove and re-roll, and a card from the Player to calculate points (eg: sea battle).
    private final Random rand;
    private CardFaces card;
    private ArrayList<Faces> hand;
    public Dice(CardFaces cardIn){
        rand = new Random();
        card = cardIn;
        hand = new ArrayList<>();
    }

    //***Methods for manipulating hands of dice***
    //Function for rolling. Gets an arraylist of random faces for an input of how many are to be rolled.
    public void roll(int num_of_rolls) {
        hand.clear();
        for (int i = 0; i< num_of_rolls; i++) {
            hand.add(Faces.myFaces(card));
        }
    }
    //Function for doing rolls after the initial one. The method takes out n random dice,
    //rolls for a new arraylist of n dice, then combines the two.
    public void reroll(int numToSwap){
        ArrayList<Faces> diceReroll = new ArrayList<>();

        int pick;
        while (numToSwap > 0){
            pick = rand.nextInt(hand.size());
            diceReroll.add(Faces.myFaces(card));
            hand.remove(pick);
            numToSwap --;
        }

        hand.addAll(diceReroll);
    }
    //Method for moving dice from a starting to end hand to simplify re-rolling. Ie, for skulls that cannot be re-rolled
    //or for held dice the user doesn't want to re-roll.
    public void moveDice(ArrayList<Faces> target, Faces item){
        Collections.sort(hand);
        int i = hand.indexOf(item);
        if (i == -1) return; //The item isn't in our hand, so just return.
        try {
            //Find the 1st instance of the face in question, then move all the ones after that are copies.
            while (hand.get(i).equals(item)) {
                target.add(item);
                i++;
            }
        }
        catch(IndexOutOfBoundsException E){}
        hand.removeAll(Collections.singleton(item));
    }
    //***Methods for getting info about the contents of a hand***
    public void addAll(ArrayList<Faces>input){
        hand.addAll(input);
    }
    public int size(){
        return hand.size();
    }
    public int frequency(Faces dice){
        return Collections.frequency(hand,dice);
    }
    public boolean contains(Faces check){
        return hand.contains(check);
    }



    //Function for calculating the points from a hand.
    public int getPoints(){
        int score = 0;
        Set<Faces> uniqueRolls = new HashSet<>(hand); //Make a hashset to remove duplicate dice.
        //First, get 100 points for each diamond and gold roll.
        score += Collections.frequency(hand, Faces.DIAMOND)*100;
        score += Collections.frequency(hand, Faces.GOLD)*100;
        //Count the number of duplicates of each die rolled:
        for (Faces i:uniqueRolls) {
            if(!i.equals(Faces.SKULL)) score += getMultiPoints(i);
        }
        //If the card isn't a nop or monkey business, it's a sea battle. Get points for it.
        if (!card.equals(CardFaces.NOP) && !card.equals(CardFaces.MONKEYBUSINESS)) score+= seaBattlePoints(card);
        return score;
    }
    public int seaBattlePoints(CardFaces card){
        int score;
        if (card.equals(CardFaces.SEABATTLE2)) score = 200;
        else if (card.equals(CardFaces.SEABATTLE3)) score = 500;
        else score = 1000;
        return score;
    }
    //Method for calculating points for 3,4,5... of a kind.
    private int getMultiPoints(Faces check)
    {
        return switch (Collections.frequency(hand, check)) {
            case 0, 1, 2 -> 0;
            case 3 -> 100;
            case 4 -> 200;
            case 5 -> 500;
            case 6 -> 1000;
            case 7 -> 2000;
            default -> 4000;
        };
    }


    public Faces findMode(ArrayList<Faces> held){
        int mode = 1;
        Faces modeObject = Faces.VOID; //I created void face as a placeholder until a most common face is found.
        for (Faces i : hand) {
            if (Collections.frequency(hand, i) > mode) { //If face is more common than previous most common, assign new
                mode = Collections.frequency(hand, i);
                modeObject = i;
            }
            //In the case of a tie, dice in the held hand take precedent, followed by diamonds/gold. Eg: 2 parrots and
            //2 gold re-rolled, but parrots are already being held. Take the parrots.
            else if (Collections.frequency(hand, i) == mode) {
                if (modeObject.equals(Faces.VOID)) modeObject = i;
                if (held.size()>0 && modeObject.equals(held.get(0))) continue;
                else if (held.size()>0 && i.equals(held.get(0))) modeObject = i;
                else if ((i.equals(Faces.DIAMOND) || i.equals(Faces.GOLD))) {
                    modeObject = i;
                }
            } //If there is a tie but not involving diamonds/gold and no dice are held, just take the last die
        }
        return modeObject;
    }
    
}



