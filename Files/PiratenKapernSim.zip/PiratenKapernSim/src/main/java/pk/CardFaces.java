package pk;

public enum CardFaces {
    SEABATTLE2, SEABATTLE3, SEABATTLE4, MONKEYBUSINESS, NOP;

}

