package pk;
    public enum Faces {
        //Dice faces, which are used when rolling hands of dice.
        MONKEY, PARROT, GOLD, DIAMOND, SABER, SKULL, VOID;
        //Apparently the sample code from the start had a method to pick a random enum.
        //I deleted it without looking at it first, so I have my own method for picking. Oh well.
        private static Faces pickRandom(int val) {
            return switch (val) {
                case 0 -> MONKEY;
                case 1, 6 -> PARROT;
                case 2 -> GOLD;
                case 3 -> DIAMOND;
                case 4 -> SABER;
                case 5 -> SKULL;
                default -> VOID;
            };
        }

        public static Faces myFaces(CardFaces card) {
            int value;
            //This is how monkey business is implemented. Just roll 1-6 so that parrot appears twice, and monkey 0 times.
            if (card.equals(CardFaces.MONKEYBUSINESS)) value = (int)(Math.random()*6 +1);
            else value = (int)(Math.random()*6);
            return Faces.pickRandom(value);
        }
    }



