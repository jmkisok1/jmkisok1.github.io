package pk;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PlayTheGame {
    //This class contains a logger for recording wins, and runGame() which acts like a main() method for playing games.
    public static final Logger logger = LogManager.getLogger(PlayTheGame.class);
    public static Deck drawDeck;
    //This was originally main() in PiratenKarpen.java. It simulates 42 games between 2 players, then outputs their
    //win rates.
    public static void runGame(String logging, String strategy1, String strategy2){
        int draws = 0;
        Player player1 = new Player(logging,"Player 1", strategy1);
        Player player2 = new Player(logging,"Player 2", strategy2);
        System.out.println("Welcome to Piraten Karpen Simulator!");
        drawDeck = new Deck(); //A public deck that's used by both players.

        for(int i = 0; i <42; i++) {
            player1.clearPoints(); //Reset points to 0 at start of game
            player2.clearPoints();
            drawDeck.deckReshuffle();
            while (true) {
                player2.fullPlay();
                //When one player reaches 6000 points, the other takes another turn, then the game stops.
                if (player2.winCondition()){
                    player1.fullPlay();
                    break;
                }
                player1.fullPlay();


                if (player1.winCondition()){
                    player2.fullPlay();
                    break;
                }
            }

            //If one player ended with more points, they get a win. I included ties because, since they
            //are so rare, a real player would be amused that they actually managed to get one.
            if (player1.getPoints() > player2.getPoints()) {
                if (logging.equals("Trace")) logger.info("Player 1 wins");
                player1.giveWin();
            }
            else if (player2.getPoints() > player1.getPoints()){
                if (logging.equals("Trace")) logger.info("Player 2 wins");
                player2.giveWin();
            }
            else {
                if (logging.equals("Trace")) logger.info("It is a draw, no wins given");
                draws++;
            }

        }
        System.out.printf("Win percentage for player 1 was %.2f%% and the win percentage for player 2 was %.2f%%.",player1.getWins()/42.0*100,player2.getWins()/42.0*100);
        if (draws==1) System.out.println("\nThere was 1 draw accounting for 2.38% of all games.");
        else if (draws>1) System.out.printf("\nThere were %d draws accounting for %.2f%% of all games.",draws,draws/42.0*100);
    }

}
