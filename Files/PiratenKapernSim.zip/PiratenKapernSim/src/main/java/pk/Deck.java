package pk;

import java.util.*;

//A deck of cards.
public class Deck {
    public List<CardFaces> myDeck;
    private final Random rand;


    public Deck(){
        myDeck = new ArrayList<>();
        rand = new Random();
        deckReshuffle();
    }

    public CardFaces pickRandom(){
        if (myDeck.isEmpty()) deckReshuffle();
        int choice = rand.nextInt(myDeck.size());
        CardFaces pick = myDeck.get(choice);
        myDeck.remove(choice);
        return pick;

    }
    public void deckReshuffle(){
        myDeck.clear();
        for (int i = 0; i<2; i++){
            myDeck.add(CardFaces.SEABATTLE2);
            myDeck.add(CardFaces.SEABATTLE3);
            myDeck.add(CardFaces.SEABATTLE4);
            for (int j =0; j<2; j++) myDeck.add(CardFaces.MONKEYBUSINESS);
        }
        myDeck.addAll(Collections.nCopies(39,CardFaces.NOP));
        Collections.shuffle(myDeck);
    }

}
